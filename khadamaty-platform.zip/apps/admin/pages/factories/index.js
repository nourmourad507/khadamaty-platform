// apps/admin/pages/factories/index.js
import { useState } from 'react';
import AdminLayout from '../../layouts/AdminLayout';
import {
  Factory, Search, Plus, MapPin, Phone, Mail, Users,
  Edit, Trash2, Eye, Package, Wrench, TrendingUp, AlertTriangle,
  CheckCircle, XCircle, BarChart3
} from 'lucide-react';
import toast from 'react-hot-toast';

const factories = [
  {
    id: 1,
    factoryCode: 'FAC-001',
    name: 'مصنع خدماتي للمواد الإنشائية',
    city: 'القاهرة',
    governorate: 'القاهرة',
    phone: '01091226300',
    email: 'factory1@khadamaty.com',
    status: 'نشط',
    workers: 45,
    products: 12,
    orders: 8,
    capacity: '5000 طن/شهر',
    category: 'مواد بناء'
  },
  {
    id: 2,
    factoryCode: 'FAC-002',
    name: 'مصنع خدماتي للأثاث المكتبي',
    city: 'العاشر من رمضان',
    governorate: 'الشرقية',
    phone: '01091226300',
    email: 'factory2@khadamaty.com',
    status: 'نشط',
    workers: 30,
    products: 8,
    orders: 5,
    capacity: '2000 قطعة/شهر',
    category: 'أثاث'
  },
  {
    id: 3,
    factoryCode: 'FAC-003',
    name: 'مصنع خدماتي للصيانة والتجهيزات',
    city: '6 أكتوبر',
    governorate: 'الجيزة',
    phone: '01091226300',
    email: 'factory3@khadamaty.com',
    status: 'صيانة',
    workers: 25,
    products: 15,
    orders: 3,
    capacity: '1000 عملية/شهر',
    category: 'صيانة'
  },
  {
    id: 4,
    factoryCode: 'FAC-004',
    name: 'مصنع خدماتي للتجهيزات الكهربائية',
    city: 'السادات',
    governorate: 'المنوفية',
    phone: '01091226300',
    email: 'factory4@khadamaty.com',
    status: 'نشط',
    workers: 35,
    products: 20,
    orders: 12,
    capacity: '3000 وحدة/شهر',
    category: 'كهرباء'
  },
];

const statusColors = {
  'نشط': 'bg-emerald-100 text-emerald-700',
  'صيانة': 'bg-amber-100 text-amber-700',
  'معلق': 'bg-orange-100 text-orange-700',
  'مغلق': 'bg-red-100 text-red-700',
};

export default function Factories() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedFactory, setSelectedFactory] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');

  const filtered = factories.filter(f => {
    const matchesSearch = f.name.includes(searchTerm) || f.factoryCode.includes(searchTerm);
    const matchesStatus = filterStatus === 'all' || f.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const totalWorkers = filtered.reduce((sum, f) => sum + f.workers, 0);
  const totalProducts = filtered.reduce((sum, f) => sum + f.products, 0);

  return (
    <AdminLayout title="إدارة المصانع" userRole="MANAGER">
      {/* Warning Banner */}
      <div className="mb-6 bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center gap-3">
        <AlertTriangle size={24} className="text-amber-600 flex-shrink-0" />
        <div>
          <h3 className="font-bold text-amber-800">قسم المصانع - خاص بالمدراء</h3>
          <p className="text-amber-700 text-sm">هذا القسم يحتوي على بيانات الإنتاج والتوريدات ولا يظهر للموظفين العاديين</p>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="admin-card flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
            <Factory size={24} className="text-emerald-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-800">{factories.length}</p>
            <p className="text-slate-500 text-sm">إجمالي المصانع</p>
          </div>
        </div>
        <div className="admin-card flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
            <Users size={24} className="text-blue-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-800">{totalWorkers}</p>
            <p className="text-slate-500 text-sm">إجمالي العمال</p>
          </div>
        </div>
        <div className="admin-card flex items-center gap-4">
          <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
            <Package size={24} className="text-purple-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-800">{totalProducts}</p>
            <p className="text-slate-500 text-sm">إجمالي المنتجات</p>
          </div>
        </div>
        <div className="admin-card flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
            <TrendingUp size={24} className="text-amber-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-800">28</p>
            <p className="text-slate-500 text-sm">أوامر الإنتاج</p>
          </div>
        </div>
      </div>

      {/* Actions Bar */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1 flex gap-4">
          <div className="relative flex-1 max-w-md">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="بحث في المصانع..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="admin-input pl-12"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="admin-input w-40"
          >
            <option value="all">كل الحالات</option>
            <option value="نشط">نشط</option>
            <option value="صيانة">صيانة</option>
            <option value="معلق">معلق</option>
            <option value="مغلق">مغلق</option>
          </select>
        </div>
        <button onClick={() => setShowAddModal(true)} className="admin-btn-primary flex items-center gap-2">
          <Plus size={18} />
          <span>مصنع جديد</span>
        </button>
      </div>

      {/* Factories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {filtered.map((factory) => (
          <div key={factory.id} className="admin-card hover:shadow-lg transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 bg-primary-100 rounded-xl flex items-center justify-center">
                  <Factory size={28} className="text-primary-600" />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-slate-800">{factory.name}</h3>
                  <p className="text-sm text-slate-500 font-mono">{factory.factoryCode}</p>
                </div>
              </div>
              <span className={`status-badge ${statusColors[factory.status] || 'bg-gray-100'}`}>
                {factory.status}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="flex items-center gap-2 text-slate-600">
                <MapPin size={16} className="text-slate-400" />
                <span className="text-sm">{factory.city}, {factory.governorate}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-600">
                <Phone size={16} className="text-slate-400" />
                <span className="text-sm">{factory.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-600">
                <Users size={16} className="text-slate-400" />
                <span className="text-sm">{factory.workers} عامل</span>
              </div>
              <div className="flex items-center gap-2 text-slate-600">
                <Package size={16} className="text-slate-400" />
                <span className="text-sm">{factory.products} منتج</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <div className="text-sm text-slate-500">
                <span className="font-medium text-slate-700">القدرة:</span> {factory.capacity}
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => { setSelectedFactory(factory); setShowDetailsModal(true); }}
                  className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-primary-600"
                  title="التفاصيل"
                >
                  <Eye size={18} />
                </button>
                <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-amber-600" title="تعديل">
                  <Edit size={18} />
                </button>
                <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-red-600" title="حذف">
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Factory Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">إضافة مصنع جديد</h2>
              <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-slate-100 rounded-lg">
                <XCircle size={20} className="text-slate-400" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">اسم المصنع</label>
                  <input type="text" className="admin-input" placeholder="مثال: مصنع خدماتي لل..." />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">التصنيف</label>
                  <select className="admin-input">
                    <option>مواد بناء</option>
                    <option>أثاث</option>
                    <option>معدات</option>
                    <option>صيانة</option>
                    <option>كهرباء</option>
                    <option>مواد غذائية</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">الحالة</label>
                  <select className="admin-input">
                    <option>نشط</option>
                    <option>صيانة</option>
                    <option>معلق</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">المحافظة</label>
                  <input type="text" className="admin-input" placeholder="القاهرة" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">المدينة</label>
                  <input type="text" className="admin-input" placeholder="مدينة نصر" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">العنوان التفصيلي</label>
                  <input type="text" className="admin-input" placeholder="العنوان الكامل" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">رقم الهاتف</label>
                  <input type="tel" className="admin-input" placeholder="01091226300" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">البريد الإلكتروني</label>
                  <input type="email" className="admin-input" placeholder="factory@khadamaty.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">السجل التجاري</label>
                  <input type="text" className="admin-input" placeholder="رقم السجل" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">البطاقة الضريبية</label>
                  <input type="text" className="admin-input" placeholder="رقم البطاقة" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">عدد العمال</label>
                  <input type="number" className="admin-input" placeholder="50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">ساعات العمل</label>
                  <input type="text" className="admin-input" placeholder="8 ساعات/يوم" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">القدرة الإنتاجية</label>
                  <input type="text" className="admin-input" placeholder="مثال: 5000 طن/شهر" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">ملاحظات</label>
                  <textarea rows={3} className="admin-input resize-none" placeholder="ملاحظات إضافية..."></textarea>
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowAddModal(false)} className="admin-btn border border-slate-200 text-slate-600 hover:bg-slate-50">
                إلغاء
              </button>
              <button onClick={() => { toast.success('تم إضافة المصنع'); setShowAddModal(false); }} className="admin-btn-primary">
                حفظ المصنع
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Factory Details Modal */}
      {showDetailsModal && selectedFactory && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center">
                  <Factory size={24} className="text-primary-600" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-800">{selectedFactory.name}</h2>
                  <p className="text-sm text-slate-500">{selectedFactory.factoryCode}</p>
                </div>
              </div>
              <button onClick={() => setShowDetailsModal(false)} className="p-2 hover:bg-slate-100 rounded-lg">
                <XCircle size={20} className="text-slate-400" />
              </button>
            </div>

            {/* Tabs */}
            <div className="border-b border-slate-200">
              <div className="flex gap-1 p-2">
                {[
                  { id: 'overview', label: 'نظرة عامة', icon: BarChart3 },
                  { id: 'products', label: 'المنتجات', icon: Package },
                  { id: 'materials', label: 'المواد الخام', icon: Wrench },
                  { id: 'orders', label: 'أوامر الإنتاج', icon: TrendingUp },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      activeTab === tab.id
                        ? 'bg-primary-50 text-primary-700'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <tab.icon size={16} />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="p-6">
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-slate-50 rounded-xl p-4 text-center">
                      <Users size={24} className="mx-auto mb-2 text-blue-600" />
                      <p className="text-2xl font-bold text-slate-800">{selectedFactory.workers}</p>
                      <p className="text-sm text-slate-500">عامل</p>
                    </div>
                    <div className="bg-slate-50 rounded-xl p-4 text-center">
                      <Package size={24} className="mx-auto mb-2 text-purple-600" />
                      <p className="text-2xl font-bold text-slate-800">{selectedFactory.products}</p>
                      <p className="text-sm text-slate-500">منتج</p>
                    </div>
                    <div className="bg-slate-50 rounded-xl p-4 text-center">
                      <TrendingUp size={24} className="mx-auto mb-2 text-emerald-600" />
                      <p className="text-2xl font-bold text-slate-800">{selectedFactory.orders}</p>
                      <p className="text-sm text-slate-500">أمر إنتاج</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-bold text-slate-800 mb-3">بيانات التواصل</h4>
                      <div className="space-y-2 text-sm">
                        <p className="flex items-center gap-2 text-slate-600">
                          <Phone size={16} /> {selectedFactory.phone}
                        </p>
                        <p className="flex items-center gap-2 text-slate-600">
                          <Mail size={16} /> {selectedFactory.email}
                        </p>
                        <p className="flex items-center gap-2 text-slate-600">
                          <MapPin size={16} /> {selectedFactory.city}, {selectedFactory.governorate}
                        </p>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800 mb-3">معلومات الإنتاج</h4>
                      <div className="space-y-2 text-sm">
                        <p className="text-slate-600"><span className="font-medium">التصنيف:</span> {selectedFactory.category}</p>
                        <p className="text-slate-600"><span className="font-medium">القدرة:</span> {selectedFactory.capacity}</p>
                        <p className="text-slate-600"><span className="font-medium">الحالة:</span> 
                          <span className={`mr-2 status-badge ${statusColors[selectedFactory.status]}`}>
                            {selectedFactory.status}
                          </span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'products' && (
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-800">منتجات المصنع</h3>
                    <button className="admin-btn-primary text-sm">إضافة منتج</button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[
                      { name: 'أسمنت بورتلاند', code: 'PRD-001', stock: 500, price: '250 ج.م/طن' },
                      { name: 'حديد تسليح 12مم', code: 'PRD-002', stock: 200, price: '18,000 ج.م/طن' },
                      { name: 'طوب أحمر', code: 'PRD-003', stock: 1000, price: '1.5 ج.م/قطعة' },
                    ].map((product, i) => (
                      <div key={i} className="border border-slate-200 rounded-xl p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-bold text-slate-800">{product.name}</h4>
                            <p className="text-sm text-slate-500">{product.code}</p>
                          </div>
                          <span className="text-emerald-600 font-bold">{product.price}</span>
                        </div>
                        <p className="text-sm text-slate-600">المخزون: {product.stock} وحدة</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'materials' && (
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-800">المواد الخام</h3>
                    <button className="admin-btn-primary text-sm">إضافة مادة</button>
                  </div>
                  <table className="admin-table">
                    <thead>
                      <tr>
                        <th>المادة</th>
                        <th>الكمية</th>
                        <th>الحد الأدنى</th>
                        <th>التكلفة</th>
                        <th>الحالة</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>حجر جيري</td>
                        <td>5000 طن</td>
                        <td>1000 طن</td>
                        <td>150 ج.م/طن</td>
                        <td><span className="status-badge bg-emerald-100 text-emerald-700">متوفر</span></td>
                      </tr>
                      <tr>
                        <td>طفلة</td>
                        <td>2000 طن</td>
                        <td>500 طن</td>
                        <td>80 ج.م/طن</td>
                        <td><span className="status-badge bg-amber-100 text-amber-700">ناقص</span></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}

              {activeTab === 'orders' && (
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-800">أوامر الإنتاج</h3>
                    <button className="admin-btn-primary text-sm">أمر إنتاج جديد</button>
                  </div>
                  <table className="admin-table">
                    <thead>
                      <tr>
                        <th>رقم الأمر</th>
                        <th>المنتج</th>
                        <th>الكمية</th>
                        <th>تاريخ التسليم</th>
                        <th>الحالة</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>PRD-2024-001</td>
                        <td>أسمنت بورتلاند</td>
                        <td>1000 طن</td>
                        <td>2024-08-15</td>
                        <td><span className="status-badge bg-blue-100 text-blue-700">قيد التنفيذ</span></td>
                      </tr>
                      <tr>
                        <td>PRD-2024-002</td>
                        <td>حديد تسليح</td>
                        <td>50 طن</td>
                        <td>2024-07-30</td>
                        <td><span className="status-badge bg-emerald-100 text-emerald-700">مكتمل</span></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
