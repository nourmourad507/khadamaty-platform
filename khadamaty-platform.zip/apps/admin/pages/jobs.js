// apps/admin/pages/jobs.js
import { useState } from 'react';
import AdminLayout from '../layouts/AdminLayout';
import { Briefcase, Search, Plus, Building, MapPin, Users, DollarSign, Edit, Trash2, Eye } from 'lucide-react';
import toast from 'react-hot-toast';

const jobs = [
  { id: 1, title: 'فني كهرباء', company: 'شركة المقاولات العربية', location: '6 أكتوبر', salary: '4,000 - 6,000', count: 5, status: 'مفتوحة', applicants: 12 },
  { id: 2, title: 'سائق نقل ثقيل', company: 'مصر للنقل', location: 'الإسكندرية', salary: '5,000 - 7,000', count: 3, status: 'مفتوحة', applicants: 8 },
  { id: 3, title: 'محاسب', company: 'شركة التجارة الدولية', location: 'القاهرة', salary: '6,000 - 8,000', count: 2, status: 'مفتوحة', applicants: 15 },
  { id: 4, title: 'أمن وحراسة', company: 'مجمع تجاري', location: 'القاهرة', salary: '3,000 - 4,000', count: 10, status: 'مغلقة', applicants: 25 },
];

const statusColors = {
  'مفتوحة': 'bg-emerald-100 text-emerald-700',
  'مغلقة': 'bg-red-100 text-red-700',
  'معلقة': 'bg-amber-100 text-amber-700',
};

export default function Jobs() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  const filtered = jobs.filter(j => 
    j.title.includes(searchTerm) || j.company.includes(searchTerm)
  );

  return (
    <AdminLayout title="إدارة الوظائف">
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="بحث عن وظيفة..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="admin-input pl-12"
          />
        </div>
        <button onClick={() => setShowAddModal(true)} className="admin-btn-primary flex items-center gap-2">
          <Plus size={18} />
          <span>وظيفة جديدة</span>
        </button>
      </div>

      <div className="admin-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="admin-table">
            <thead>
              <tr>
                <th>الوظيفة</th>
                <th>الشركة</th>
                <th>الموقع</th>
                <th>الراتب</th>
                <th>المطلوب</th>
                <th>المتقدمين</th>
                <th>الحالة</th>
                <th>الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((job) => (
                <tr key={job.id} className="hover:bg-slate-50 transition-colors">
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
                        <Briefcase size={18} className="text-primary-600" />
                      </div>
                      <span className="font-medium text-slate-800">{job.title}</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 text-slate-600">
                      <Building size={14} />
                      <span>{job.company}</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 text-slate-500">
                      <MapPin size={14} />
                      <span>{job.location}</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 text-slate-700 font-medium">
                      <DollarSign size={14} className="text-emerald-500" />
                      <span>{job.salary} ج.م</span>
                    </div>
                  </td>
                  <td className="text-slate-600">{job.count} موظف</td>
                  <td>
                    <div className="flex items-center gap-1 text-slate-600">
                      <Users size={14} />
                      <span>{job.applicants} متقدم</span>
                    </div>
                  </td>
                  <td>
                    <span className={`status-badge ${statusColors[job.status] || 'bg-gray-100'}`}>
                      {job.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-primary-600">
                        <Eye size={16} />
                      </button>
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-amber-600">
                        <Edit size={16} />
                      </button>
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-red-600">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
