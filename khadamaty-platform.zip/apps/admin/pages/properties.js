// apps/admin/pages/properties.js
import { useState } from 'react';
import AdminLayout from '../layouts/AdminLayout';
import { Building, Search, Plus, Filter, Edit, Trash2, Eye, MapPin, Bed, Bath, Maximize } from 'lucide-react';
import toast from 'react-hot-toast';

const properties = [
  { id: 1, code: 'PROP-001', title: 'شقة فاخرة - التجمع الخامس', type: 'شقة', area: 150, rooms: 3, bathrooms: 2, price: 2500000, status: 'متاح', region: 'التجمع الخامس', city: 'القاهرة' },
  { id: 2, code: 'PROP-002', title: 'فيلا - الشيخ زايد', type: 'فيلا', area: 400, rooms: 5, bathrooms: 4, price: 8000000, status: 'محجوز', region: 'الشيخ زايد', city: 'الجيزة' },
  { id: 3, code: 'PROP-003', title: 'محل تجاري - مدينة نصر', type: 'محل', area: 80, rooms: 0, bathrooms: 1, price: 3200000, status: 'متاح', region: 'مدينة نصر', city: 'القاهرة' },
  { id: 4, code: 'PROP-004', title: 'دوبلكس - القاهرة الجديدة', type: 'دوبلكس', area: 220, rooms: 4, bathrooms: 3, price: 4500000, status: 'متاح', region: 'القاهرة الجديدة', city: 'القاهرة' },
  { id: 5, code: 'PROP-005', title: 'أرض - 6 أكتوبر', type: 'أرض', area: 600, rooms: 0, bathrooms: 0, price: 1200000, status: 'متاح', region: '6 أكتوبر', city: 'الجيزة' },
];

const statusColors = {
  'متاح': 'bg-emerald-100 text-emerald-700',
  'محجوز': 'bg-amber-100 text-amber-700',
  'تم البيع': 'bg-blue-100 text-blue-700',
  'متوقف': 'bg-red-100 text-red-700',
};

export default function Properties() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);

  const filtered = properties.filter(p => {
    const matchesSearch = p.title.includes(searchTerm) || p.code.includes(searchTerm);
    const matchesStatus = filterStatus === 'all' || p.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <AdminLayout title="إدارة العقارات">
      {/* Actions Bar */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1 flex gap-4">
          <div className="relative flex-1 max-w-md">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="بحث عن عقار..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="admin-input pl-12"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="admin-input w-40"
          >
            <option value="all">كل الحالات</option>
            <option value="متاح">متاح</option>
            <option value="محجوز">محجوز</option>
            <option value="تم البيع">تم البيع</option>
            <option value="متوقف">متوقف</option>
          </select>
        </div>
        <button onClick={() => setShowAddModal(true)} className="admin-btn-primary flex items-center gap-2">
          <Plus size={18} />
          <span>إضافة عقار</span>
        </button>
      </div>

      {/* Properties Table */}
      <div className="admin-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="admin-table">
            <thead>
              <tr>
                <th>الكود</th>
                <th>العقار</th>
                <th>النوع</th>
                <th>المساحة</th>
                <th>الغرف</th>
                <th>السعر</th>
                <th>الحالة</th>
                <th>الموقع</th>
                <th>الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((property) => (
                <tr key={property.id} className="hover:bg-slate-50 transition-colors">
                  <td className="font-mono text-sm text-slate-500">{property.code}</td>
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center">
                        <Building size={18} className="text-primary-600" />
                      </div>
                      <span className="font-medium text-slate-800">{property.title}</span>
                    </div>
                  </td>
                  <td>{property.type}</td>
                  <td>
                    <div className="flex items-center gap-1">
                      <Maximize size={14} className="text-slate-400" />
                      <span>{property.area}م²</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-1">
                      <Bed size={14} className="text-slate-400" />
                      <span>{property.rooms}</span>
                    </div>
                  </td>
                  <td className="font-bold text-primary-700">{property.price.toLocaleString()} ج.م</td>
                  <td>
                    <span className={`status-badge ${statusColors[property.status] || 'bg-gray-100 text-gray-700'}`}>
                      {property.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 text-slate-500">
                      <MapPin size={14} />
                      <span className="text-sm">{property.region}</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-primary-600 transition-colors">
                        <Eye size={16} />
                      </button>
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-amber-600 transition-colors">
                        <Edit size={16} />
                      </button>
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-red-600 transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-100">
          <p className="text-sm text-slate-500">عرض {filtered.length} من {properties.length} عقار</p>
          <div className="flex gap-2">
            <button className="px-3 py-1 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm">السابق</button>
            <button className="px-3 py-1 rounded-lg bg-primary-600 text-white text-sm">1</button>
            <button className="px-3 py-1 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-sm">التالي</button>
          </div>
        </div>
      </div>

      {/* Add Property Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">إضافة عقار جديد</h2>
              <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-slate-100 rounded-lg">
                <Trash2 size={20} className="text-slate-400" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">اسم المشروع</label>
                  <input type="text" className="admin-input" placeholder="مثال: كمبوند النخيل" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">نوع العقار</label>
                  <select className="admin-input">
                    <option>شقة</option>
                    <option>فيلا</option>
                    <option>دوبلكس</option>
                    <option>مكتب</option>
                    <option>محل</option>
                    <option>أرض</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">المنطقة</label>
                  <input type="text" className="admin-input" placeholder="التجمع الخامس" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">المحافظة</label>
                  <input type="text" className="admin-input" placeholder="القاهرة" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">المساحة (م²)</label>
                  <input type="number" className="admin-input" placeholder="150" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">السعر (ج.م)</label>
                  <input type="number" className="admin-input" placeholder="2500000" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">عدد الغرف</label>
                  <input type="number" className="admin-input" placeholder="3" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">عدد الحمامات</label>
                  <input type="number" className="admin-input" placeholder="2" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">الوصف</label>
                <textarea rows={3} className="admin-input resize-none" placeholder="وصف تفصيلي للعقار..."></textarea>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowAddModal(false)} className="admin-btn border border-slate-200 text-slate-600 hover:bg-slate-50">
                إلغاء
              </button>
              <button onClick={() => { toast.success('تم إضافة العقار'); setShowAddModal(false); }} className="admin-btn-primary">
                حفظ العقار
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
