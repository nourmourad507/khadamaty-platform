// apps/admin/pages/dashboard.js
import AdminLayout from '../layouts/AdminLayout';
import {
  Building, Users, Phone, Briefcase, TrendingUp, TrendingDown,
  DollarSign, Calendar, ArrowUpRight, ArrowDownRight
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const stats = [
  { title: 'إجمالي العملاء', value: '1,245', change: '+12%', trend: 'up', icon: Users, color: 'bg-blue-500' },
  { title: 'العقارات المتاحة', value: '386', change: '+5%', trend: 'up', icon: Building, color: 'bg-emerald-500' },
  { title: 'الصفقات المغلقة', value: '52', change: '-3%', trend: 'down', icon: DollarSign, color: 'bg-amber-500' },
  { title: 'الوظائف المفتوحة', value: '24', change: '+8%', trend: 'up', icon: Briefcase, color: 'bg-purple-500' },
];

const monthlyData = [
  { name: 'يناير', customers: 65, properties: 28, leads: 45 },
  { name: 'فبراير', customers: 78, properties: 35, leads: 52 },
  { name: 'مارس', customers: 90, properties: 42, leads: 61 },
  { name: 'أبريل', customers: 85, properties: 38, leads: 55 },
  { name: 'مايو', customers: 110, properties: 50, leads: 72 },
  { name: 'يونيو', customers: 125, properties: 55, leads: 80 },
];

const sourceData = [
  { name: 'فيسبوك', value: 45, color: '#1877f2' },
  { name: 'واتساب', value: 30, color: '#25d366' },
  { name: 'إحالات', value: 15, color: '#f59e0b' },
  { name: 'إعلانات', value: 10, color: '#ef4444' },
];

const recentActivities = [
  { user: 'أحمد محمد', action: 'أضاف عقار جديد', time: 'منذ 5 دقائق', type: 'property' },
  { user: 'سارة علي', action: 'اتصلت بعميل جديد', time: 'منذ 15 دقيقة', type: 'call' },
  { user: 'محمد خالد', action: 'أغلق صفقة بيع', time: 'منذ 30 دقيقة', type: 'deal' },
  { user: 'نورا سامي', action: 'أضافت طلب خدمة', time: 'منذ ساعة', type: 'service' },
];

export default function Dashboard() {
  return (
    <AdminLayout title="الرئيسية">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="admin-card">
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center text-white`}>
                <stat.icon size={24} />
              </div>
              <div className={`flex items-center gap-1 text-sm font-medium ${
                stat.trend === 'up' ? 'text-emerald-600' : 'text-red-600'
              }`}>
                {stat.trend === 'up' ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                <span>{stat.change}</span>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-slate-800 mb-1">{stat.value}</h3>
            <p className="text-slate-500 text-sm">{stat.title}</p>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Main Chart */}
        <div className="admin-card lg:col-span-2">
          <h3 className="font-bold text-lg text-slate-800 mb-6">إحصائيات شهرية</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
              <Bar dataKey="customers" fill="#0f766e" radius={[4, 4, 0, 0]} name="العملاء" />
              <Bar dataKey="properties" fill="#f59e0b" radius={[4, 4, 0, 0]} name="العقارات" />
              <Bar dataKey="leads" fill="#0ea5e9" radius={[4, 4, 0, 0]} name="العملاء المحتملين" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie Chart */}
        <div className="admin-card">
          <h3 className="font-bold text-lg text-slate-800 mb-6">مصادر العملاء</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={sourceData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {sourceData.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {sourceData.map((item, index) => (
              <div key={index} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-600">{item.name}</span>
                </div>
                <span className="font-bold text-slate-800">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activities */}
        <div className="admin-card">
          <h3 className="font-bold text-lg text-slate-800 mb-6">آخر النشاطات</h3>
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-start gap-4 pb-4 border-b border-slate-100 last:border-0">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                  activity.type === 'property' ? 'bg-emerald-100 text-emerald-600' :
                  activity.type === 'call' ? 'bg-blue-100 text-blue-600' :
                  activity.type === 'deal' ? 'bg-amber-100 text-amber-600' :
                  'bg-purple-100 text-purple-600'
                }`}>
                  <Users size={18} />
                </div>
                <div className="flex-1">
                  <p className="text-slate-800">
                    <span className="font-bold">{activity.user}</span>{' '}
                    <span className="text-slate-500">{activity.action}</span>
                  </p>
                  <p className="text-slate-400 text-sm mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="admin-card">
          <h3 className="font-bold text-lg text-slate-800 mb-6">إجراءات سريعة</h3>
          <div className="grid grid-cols-2 gap-4">
            <button className="p-4 bg-primary-50 rounded-xl text-primary-700 hover:bg-primary-100 transition-colors text-center">
              <Building size={28} className="mx-auto mb-2" />
              <span className="font-medium text-sm">إضافة عقار</span>
            </button>
            <button className="p-4 bg-blue-50 rounded-xl text-blue-700 hover:bg-blue-100 transition-colors text-center">
              <Users size={28} className="mx-auto mb-2" />
              <span className="font-medium text-sm">عميل جديد</span>
            </button>
            <button className="p-4 bg-amber-50 rounded-xl text-amber-700 hover:bg-amber-100 transition-colors text-center">
              <Phone size={28} className="mx-auto mb-2" />
              <span className="font-medium text-sm">سجل مكالمة</span>
            </button>
            <button className="p-4 bg-purple-50 rounded-xl text-purple-700 hover:bg-purple-100 transition-colors text-center">
              <Briefcase size={28} className="mx-auto mb-2" />
              <span className="font-medium text-sm">وظيفة جديدة</span>
            </button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
