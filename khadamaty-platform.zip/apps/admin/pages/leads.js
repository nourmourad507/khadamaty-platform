// apps/admin/pages/leads.js
import { useState } from 'react';
import AdminLayout from '../layouts/AdminLayout';
import { Phone, Search, Plus, Filter, Edit, MessageCircle, Calendar, CheckCircle, XCircle, Clock } from 'lucide-react';
import toast from 'react-hot-toast';

const leads = [
  { id: 1, customer: 'محمد أحمد', property: 'شقة - التجمع الخامس', status: 'متابعة', nextTask: 'اتصال هاتفي', nextDate: '2024-07-12', assignedTo: 'أحمد علي' },
  { id: 2, customer: 'سارة خالد', property: 'فيلا - الشيخ زايد', status: 'زيارة مقررة', nextTask: 'زيارة العقار', nextDate: '2024-07-13', assignedTo: 'نورا سامي' },
  { id: 3, customer: 'خالد محمود', property: 'محل - مدينة نصر', status: 'تفاوض', nextTask: 'إرسال عرض سعر', nextDate: '2024-07-11', assignedTo: 'أحمد علي' },
  { id: 4, customer: 'فاطمة حسن', property: 'دوبلكس - القاهرة الجديدة', status: 'مغلق ناجح', nextTask: '-', nextDate: '-', assignedTo: 'محمد خالد' },
];

const statusColors = {
  'جديد': 'bg-blue-100 text-blue-700',
  'متابعة': 'bg-amber-100 text-amber-700',
  'زيارة مقررة': 'bg-purple-100 text-purple-700',
  'تفاوض': 'bg-orange-100 text-orange-700',
  'مغلق ناجح': 'bg-emerald-100 text-emerald-700',
  'مغلق فاشل': 'bg-red-100 text-red-700',
};

export default function Leads() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  const filtered = leads.filter(l => 
    l.customer.includes(searchTerm) || l.property.includes(searchTerm)
  );

  return (
    <AdminLayout title="العملاء المحتملين">
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="بحث..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="admin-input pl-12"
          />
        </div>
        <button onClick={() => setShowAddModal(true)} className="admin-btn-primary flex items-center gap-2">
          <Plus size={18} />
          <span>إضافة متابعة</span>
        </button>
      </div>

      <div className="admin-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="admin-table">
            <thead>
              <tr>
                <th>العميل</th>
                <th>العقار</th>
                <th>الحالة</th>
                <th>المهمة القادمة</th>
                <th>التاريخ</th>
                <th>المسؤول</th>
                <th>الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((lead) => (
                <tr key={lead.id} className="hover:bg-slate-50 transition-colors">
                  <td className="font-medium text-slate-800">{lead.customer}</td>
                  <td className="text-slate-600">{lead.property}</td>
                  <td>
                    <span className={`status-badge ${statusColors[lead.status] || 'bg-gray-100'}`}>
                      {lead.status}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 text-slate-600">
                      <Clock size={14} />
                      <span>{lead.nextTask}</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 text-slate-500">
                      <Calendar size={14} />
                      <span>{lead.nextDate}</span>
                    </div>
                  </td>
                  <td className="text-slate-600">{lead.assignedTo}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-green-600">
                        <CheckCircle size={16} />
                      </button>
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-amber-600">
                        <Edit size={16} />
                      </button>
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-red-600">
                        <XCircle size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
