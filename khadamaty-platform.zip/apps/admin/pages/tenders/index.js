// apps/admin/pages/tenders/index.js
import { useState } from 'react';
import AdminLayout from '../../layouts/AdminLayout';
import {
  FileText, Search, Plus, Filter, Building, Calendar, DollarSign,
  Edit, Trash2, Eye, Download, CheckCircle, XCircle, Clock, Award
} from 'lucide-react';
import toast from 'react-hot-toast';

const tenders = [
  {
    id: 1,
    tenderNumber: 'TND-2024-001',
    title: 'توريد مواد بناء - مشروع إسكان اجتماعي',
    type: 'حكومية',
    issuerName: 'وزارة الإسكان',
    issuerType: 'حكومي',
    estimatedValue: 2500000,
    publishDate: '2024-07-01',
    closingDate: '2024-08-15',
    status: 'منشورة',
    bidsCount: 0,
    factory: 'مصنع خدماتي للمواد الإنشائية'
  },
  {
    id: 2,
    tenderNumber: 'TND-2024-002',
    title: 'توريد أثاث مكتبي - شركة النصر',
    type: 'خاصة',
    issuerName: 'شركة النصر للتجارة',
    issuerType: 'شركة خاصة',
    estimatedValue: 800000,
    publishDate: '2024-07-05',
    closingDate: '2024-07-25',
    status: 'تم تقديم العرض',
    bidsCount: 1,
    factory: 'مصنع خدماتي للأثاث'
  },
  {
    id: 3,
    tenderNumber: 'TND-2024-003',
    title: 'صيانة معدات - القوات المسلحة',
    type: 'حكومية',
    issuerName: 'الإدارة الهندسية',
    issuerType: 'عسكري',
    estimatedValue: 1500000,
    publishDate: '2024-06-20',
    closingDate: '2024-07-10',
    status: 'تمت الترسية',
    bidsCount: 2,
    factory: 'مصنع خدماتي للصيانة'
  },
  {
    id: 4,
    tenderNumber: 'TND-2024-004',
    title: 'توريد معدات كهربائية - محافظة الجيزة',
    type: 'حكومية',
    issuerName: 'محافظة الجيزة',
    issuerType: 'حكومي',
    estimatedValue: 3200000,
    publishDate: '2024-07-10',
    closingDate: '2024-08-30',
    status: 'تحت المراجعة',
    bidsCount: 1,
    factory: 'مصنع خدماتي للكهرباء'
  },
];

const statusColors = {
  'مسودة': 'bg-slate-100 text-slate-700',
  'منشورة': 'bg-blue-100 text-blue-700',
  'تحت المراجعة': 'bg-amber-100 text-amber-700',
  'تم تقديم العرض': 'bg-purple-100 text-purple-700',
  'تحت التقييم': 'bg-orange-100 text-orange-700',
  'تمت الترسية': 'bg-emerald-100 text-emerald-700',
  'مرفوضة': 'bg-red-100 text-red-700',
  'ملغاة': 'bg-gray-100 text-gray-700',
  'منفذة': 'bg-sky-100 text-sky-700',
};

const typeColors = {
  'حكومية': 'bg-red-50 text-red-700 border border-red-200',
  'خاصة': 'bg-blue-50 text-blue-700 border border-blue-200',
  'دولية': 'bg-purple-50 text-purple-700 border border-purple-200',
  'محلية': 'bg-green-50 text-green-700 border border-green-200',
};

export default function Tenders() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showBidModal, setShowBidModal] = useState(false);
  const [selectedTender, setSelectedTender] = useState(null);

  const filtered = tenders.filter(t => {
    const matchesSearch = t.title.includes(searchTerm) || t.tenderNumber.includes(searchTerm);
    const matchesStatus = filterStatus === 'all' || t.status === filterStatus;
    const matchesType = filterType === 'all' || t.type === filterType;
    return matchesSearch && matchesStatus && matchesType;
  });

  const totalValue = filtered.reduce((sum, t) => sum + t.estimatedValue, 0);

  return (
    <AdminLayout title="إدارة المناقصات" userRole="MANAGER">
      {/* Warning Banner */}
      <div className="mb-6 bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-center gap-3">
        <Award size={24} className="text-amber-600 flex-shrink-0" />
        <div>
          <h3 className="font-bold text-amber-800">قسم المناقصات - خاص بالمدراء</h3>
          <p className="text-amber-700 text-sm">هذا القسم يحتوي على بيانات حساسة ولا يظهر للموظفين العاديين</p>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="admin-card flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
            <FileText size={24} className="text-blue-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-800">{tenders.length}</p>
            <p className="text-slate-500 text-sm">إجمالي المناقصات</p>
          </div>
        </div>
        <div className="admin-card flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
            <CheckCircle size={24} className="text-emerald-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-800">
              {tenders.filter(t => t.status === 'تمت الترسية').length}
            </p>
            <p className="text-slate-500 text-sm">مناقصات ناجحة</p>
          </div>
        </div>
        <div className="admin-card flex items-center gap-4">
          <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
            <Clock size={24} className="text-amber-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-800">
              {tenders.filter(t => t.status === 'منشورة' || t.status === 'تحت المراجعة').length}
            </p>
            <p className="text-slate-500 text-sm">قيد المتابعة</p>
          </div>
        </div>
        <div className="admin-card flex items-center gap-4">
          <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
            <DollarSign size={24} className="text-purple-600" />
          </div>
          <div>
            <p className="text-2xl font-bold text-slate-800">{totalValue.toLocaleString()}</p>
            <p className="text-slate-500 text-sm">إجمالي القيمة (ج.م)</p>
          </div>
        </div>
      </div>

      {/* Actions Bar */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1 flex gap-4">
          <div className="relative flex-1 max-w-md">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="بحث في المناقصات..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="admin-input pl-12"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="admin-input w-40"
          >
            <option value="all">كل الحالات</option>
            <option value="منشورة">منشورة</option>
            <option value="تحت المراجعة">تحت المراجعة</option>
            <option value="تم تقديم العرض">تم تقديم العرض</option>
            <option value="تمت الترسية">تمت الترسية</option>
            <option value="مرفوضة">مرفوضة</option>
          </select>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="admin-input w-40"
          >
            <option value="all">كل الأنواع</option>
            <option value="حكومية">حكومية</option>
            <option value="خاصة">خاصة</option>
            <option value="دولية">دولية</option>
          </select>
        </div>
        <button onClick={() => setShowAddModal(true)} className="admin-btn-primary flex items-center gap-2">
          <Plus size={18} />
          <span>مناقصة جديدة</span>
        </button>
      </div>

      {/* Tenders Table */}
      <div className="admin-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="admin-table">
            <thead>
              <tr>
                <th>الرقم</th>
                <th>المناقصة</th>
                <th>النوع</th>
                <th>الجهة</th>
                <th>القيمة التقديرية</th>
                <th>تاريخ الإغلاق</th>
                <th>الحالة</th>
                <th>العروض</th>
                <th>الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((tender) => (
                <tr key={tender.id} className="hover:bg-slate-50 transition-colors">
                  <td className="font-mono text-sm text-slate-500">{tender.tenderNumber}</td>
                  <td>
                    <div>
                      <p className="font-medium text-slate-800">{tender.title}</p>
                      <p className="text-xs text-slate-500">{tender.factory}</p>
                    </div>
                  </td>
                  <td>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${typeColors[tender.type] || 'bg-gray-100'}`}>
                      {tender.type}
                    </span>
                  </td>
                  <td>
                    <div>
                      <p className="text-slate-700">{tender.issuerName}</p>
                      <p className="text-xs text-slate-500">{tender.issuerType}</p>
                    </div>
                  </td>
                  <td className="font-bold text-slate-800">{tender.estimatedValue.toLocaleString()} ج.م</td>
                  <td>
                    <div className="flex items-center gap-1 text-slate-600">
                      <Calendar size={14} />
                      <span>{tender.closingDate}</span>
                    </div>
                  </td>
                  <td>
                    <span className={`status-badge ${statusColors[tender.status] || 'bg-gray-100'}`}>
                      {tender.status}
                    </span>
                  </td>
                  <td>
                    <span className="text-sm text-slate-600">{tender.bidsCount} عرض</span>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-primary-600" title="عرض التفاصيل">
                        <Eye size={16} />
                      </button>
                      <button 
                        onClick={() => { setSelectedTender(tender); setShowBidModal(true); }}
                        className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-emerald-600"
                        title="تقديم عرض"
                      >
                        <Award size={16} />
                      </button>
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-amber-600" title="تعديل">
                        <Edit size={16} />
                      </button>
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-red-600" title="حذف">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Tender Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">إضافة مناقصة جديدة</h2>
              <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-slate-100 rounded-lg">
                <XCircle size={20} className="text-slate-400" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">عنوان المناقصة</label>
                  <input type="text" className="admin-input" placeholder="مثال: توريد مواد بناء - مشروع إسكان" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">نوع المناقصة</label>
                  <select className="admin-input">
                    <option value="GOVERNMENT">حكومية</option>
                    <option value="PRIVATE">خاصة</option>
                    <option value="INTERNATIONAL">دولية</option>
                    <option value="LOCAL">محلية</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">التصنيف</label>
                  <select className="admin-input">
                    <option>مواد بناء</option>
                    <option>أثاث</option>
                    <option>معدات</option>
                    <option>صيانة</option>
                    <option>خدمات</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">جهة الطرح</label>
                  <input type="text" className="admin-input" placeholder="اسم الجهة" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">نوع الجهة</label>
                  <select className="admin-input">
                    <option>حكومي</option>
                    <option>عسكري</option>
                    <option>شركة خاصة</option>
                    <option>مؤسسة دولية</option>
                    <option>جمعية أهلية</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">القيمة التقديرية (ج.م)</label>
                  <input type="number" className="admin-input" placeholder="2500000" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">تاريخ النشر</label>
                  <input type="date" className="admin-input" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">تاريخ الإغلاق</label>
                  <input type="date" className="admin-input" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">المصنع المسؤول</label>
                  <select className="admin-input">
                    <option>مصنع خدماتي للمواد الإنشائية</option>
                    <option>مصنع خدماتي للأثاث</option>
                    <option>مصنع خدماتي للصيانة</option>
                    <option>مصنع خدماتي للكهرباء</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">المسؤول عن المتابعة</label>
                  <select className="admin-input">
                    <option>أحمد محمد</option>
                    <option>سارة علي</option>
                    <option>محمد خالد</option>
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">الشروط والمتطلبات</label>
                  <textarea rows={3} className="admin-input resize-none" placeholder="شروط المناقصة..."></textarea>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">ملفات المناقصة</label>
                  <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-primary-400 transition-colors cursor-pointer">
                    <Download size={24} className="mx-auto mb-2 text-slate-400" />
                    <p className="text-slate-500">اسحب الملفات هنا أو اضغط للرفع</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowAddModal(false)} className="admin-btn border border-slate-200 text-slate-600 hover:bg-slate-50">
                إلغاء
              </button>
              <button onClick={() => { toast.success('تم إضافة المناقصة'); setShowAddModal(false); }} className="admin-btn-primary">
                حفظ المناقصة
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Submit Bid Modal */}
      {showBidModal && selectedTender && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-slate-100">
              <h2 className="text-xl font-bold text-slate-800">تقديم عرض للمناقصة</h2>
              <p className="text-slate-500 text-sm mt-1">{selectedTender.title}</p>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">قيمة العرض (ج.م)</label>
                <input type="number" className="admin-input" placeholder="أقل من القيمة التقديرية" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">مدة التنفيذ (يوم)</label>
                <input type="number" className="admin-input" placeholder="30" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ملخص العرض الفني</label>
                <textarea rows={3} className="admin-input resize-none" placeholder="وصف العرض..."></textarea>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">مستندات العرض</label>
                <div className="border-2 border-dashed border-slate-300 rounded-xl p-4 text-center">
                  <p className="text-slate-500 text-sm">رفع المستندات الفنية والمالية</p>
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowBidModal(false)} className="admin-btn border border-slate-200 text-slate-600">إلغاء</button>
              <button onClick={() => { toast.success('تم تقديم العرض'); setShowBidModal(false); }} className="admin-btn-primary">
                تقديم العرض
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
