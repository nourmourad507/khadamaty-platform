// apps/admin/pages/index.js
import { useState } from 'react';
import { useRouter } from 'next/router';
import { Building, Eye, EyeOff, Lock, Mail } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Demo login - in production, call API
      if (email && password) {
        toast.success('تم تسجيل الدخول بنجاح');
        router.push('/dashboard');
      } else {
        toast.error('يرجى إدخال البريد وكلمة المرور');
      }
    } catch (error) {
      toast.error('خطأ في تسجيل الدخول');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-900 via-primary-800 to-slate-900">
      <div className="w-full max-w-md p-8">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="w-20 h-20 mx-auto bg-white/10 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/20 mb-6">
            <svg width="48" height="48" viewBox="0 0 200 200" fill="none">
              <rect x="60" y="70" width="55" height="90" rx="3" fill="white"/>
              <rect x="35" y="95" width="28" height="65" rx="2" fill="white" opacity="0.8"/>
              <rect x="112" y="95" width="28" height="65" rx="2" fill="white" opacity="0.8"/>
              <rect x="72" y="55" width="32" height="18" rx="2" fill="#fbbf24"/>
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">خدماتي</h1>
          <p className="text-primary-200">لوحة تحكم الإدارة</p>
        </div>

        {/* Login Form */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-white/80 text-sm mb-2 font-medium">البريد الإلكتروني</label>
              <div className="relative">
                <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/40 outline-none focus:border-accent-400 focus:ring-2 focus:ring-accent-400/20 transition-all"
                  placeholder="admin@khadamaty.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-white/80 text-sm mb-2 font-medium">كلمة المرور</label>
              <div className="relative">
                <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/40 outline-none focus:border-accent-400 focus:ring-2 focus:ring-accent-400/20 transition-all"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center gap-2 text-white/60 cursor-pointer">
                <input type="checkbox" className="rounded accent-accent-500" />
                <span>تذكرني</span>
              </label>
              <a href="#" className="text-accent-400 hover:text-accent-300">نسيت كلمة المرور؟</a>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-accent-500 hover:bg-accent-600 text-white font-bold rounded-xl transition-all duration-300 shadow-lg shadow-accent-500/25 disabled:opacity-50"
            >
              {loading ? 'جاري الدخول...' : 'تسجيل الدخول'}
            </button>
          </form>
        </div>

        <p className="text-center text-white/40 text-sm mt-6">
          © 2024 شركة خدماتي. جميع الحقوق محفوظة.
        </p>
      </div>
    </div>
  );
}
