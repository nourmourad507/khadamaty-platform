// apps/admin/pages/_app.js
import '../styles/globals.css';
import { Toaster } from 'react-hot-toast';
import Head from 'next/head';

function AdminApp({ Component, pageProps }) {
  return (
    <>
      <Head>
        <title>لوحة التحكم | خدماتي</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/assets/logo/khadamaty-icon.svg" />
      </Head>
      <Toaster position="top-left" />
      <Component {...pageProps} />
    </>
  );
}

export default AdminApp;
