// apps/admin/pages/customers.js
import { useState } from 'react';
import AdminLayout from '../layouts/AdminLayout';
import { Users, Search, Plus, Phone, Mail, MapPin, Star, Edit, Trash2, Eye, MessageCircle } from 'lucide-react';
import toast from 'react-hot-toast';

const customers = [
  { id: 1, name: 'محمد أحمد', phone: '01012345678', email: 'mohamed@email.com', source: 'فيسبوك', status: 'مهتم', need: 'شقة', budget: '2-3 مليون', region: 'التجمع الخامس', assignedTo: 'أحمد علي' },
  { id: 2, name: 'سارة خالد', phone: '01098765432', email: 'sara@email.com', source: 'واتساب', status: 'تم التعاقد', need: 'فيلا', budget: '5-8 مليون', region: 'الشيخ زايد', assignedTo: 'نورا سامي' },
  { id: 3, name: 'خالد محمود', phone: '01055556666', email: 'khaled@email.com', source: 'إحالة', status: 'جديد', need: 'محل', budget: '1-2 مليون', region: 'مدينة نصر', assignedTo: 'أحمد علي' },
  { id: 4, name: 'فاطمة حسن', phone: '01077778888', email: 'fatima@email.com', source: 'إعلان', status: 'زيارة', need: 'دوبلكس', budget: '3-5 مليون', region: 'القاهرة الجديدة', assignedTo: 'محمد خالد' },
  { id: 5, name: 'عمر سعيد', phone: '01099990000', email: 'omar@email.com', source: 'موقع', status: 'تفاوض', need: 'شقة', budget: '2-4 مليون', region: '6 أكتوبر', assignedTo: 'سارة علي' },
];

const statusColors = {
  'جديد': 'bg-blue-100 text-blue-700',
  'تم الاتصال': 'bg-slate-100 text-slate-700',
  'مهتم': 'bg-amber-100 text-amber-700',
  'زيارة': 'bg-purple-100 text-purple-700',
  'تفاوض': 'bg-orange-100 text-orange-700',
  'تم التعاقد': 'bg-emerald-100 text-emerald-700',
  'غير مهتم': 'bg-red-100 text-red-700',
};

export default function Customers() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  const filtered = customers.filter(c => 
    c.name.includes(searchTerm) || c.phone.includes(searchTerm) || c.email.includes(searchTerm)
  );

  return (
    <AdminLayout title="إدارة العملاء">
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1 flex gap-4">
          <div className="relative flex-1 max-w-md">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="بحث عن عميل..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="admin-input pl-12"
            />
          </div>
        </div>
        <button onClick={() => setShowAddModal(true)} className="admin-btn-primary flex items-center gap-2">
          <Plus size={18} />
          <span>عميل جديد</span>
        </button>
      </div>

      <div className="admin-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="admin-table">
            <thead>
              <tr>
                <th>العميل</th>
                <th>التواصل</th>
                <th>المصدر</th>
                <th>الاحتياج</th>
                <th>الميزانية</th>
                <th>المنطقة</th>
                <th>الحالة</th>
                <th>المسؤول</th>
                <th>الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((customer) => (
                <tr key={customer.id} className="hover:bg-slate-50 transition-colors">
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                        <span className="text-primary-700 font-bold">{customer.name[0]}</span>
                      </div>
                      <div>
                        <p className="font-medium text-slate-800">{customer.name}</p>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div className="space-y-1">
                      <a href={`tel:${customer.phone}`} className="flex items-center gap-1 text-sm text-slate-600 hover:text-primary-600">
                        <Phone size={14} /> {customer.phone}
                      </a>
                      {customer.email && (
                        <a href={`mailto:${customer.email}`} className="flex items-center gap-1 text-sm text-slate-500 hover:text-primary-600">
                          <Mail size={14} /> {customer.email}
                        </a>
                      )}
                    </div>
                  </td>
                  <td>
                    <span className="text-sm text-slate-600">{customer.source}</span>
                  </td>
                  <td>
                    <span className="text-sm font-medium text-slate-700">{customer.need}</span>
                  </td>
                  <td>
                    <span className="text-sm text-slate-600">{customer.budget}</span>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 text-sm text-slate-500">
                      <MapPin size={14} /> {customer.region}
                    </div>
                  </td>
                  <td>
                    <span className={`status-badge ${statusColors[customer.status] || 'bg-gray-100'}`}>
                      {customer.status}
                    </span>
                  </td>
                  <td>
                    <span className="text-sm text-slate-600">{customer.assignedTo}</span>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-primary-600">
                        <Eye size={16} />
                      </button>
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-amber-600">
                        <Edit size={16} />
                      </button>
                      <a href={`https://wa.me/${customer.phone}`} target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 hover:text-green-600">
                        <MessageCircle size={16} />
                      </a>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-slate-100">
              <h2 className="text-xl font-bold text-slate-800">إضافة عميل جديد</h2>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">الاسم</label>
                  <input type="text" className="admin-input" placeholder="اسم العميل" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">رقم الهاتف</label>
                  <input type="tel" className="admin-input" placeholder="01xxxxxxxxxx" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">واتساب</label>
                  <input type="tel" className="admin-input" placeholder="01xxxxxxxxxx" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">البريد</label>
                  <input type="email" className="admin-input" placeholder="email@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">المصدر</label>
                  <select className="admin-input">
                    <option>فيسبوك</option>
                    <option>واتساب</option>
                    <option>إعلان</option>
                    <option>إحالة</option>
                    <option>موقع</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">نوع العقار المطلوب</label>
                  <select className="admin-input">
                    <option>شقة</option>
                    <option>فيلا</option>
                    <option>دوبلكس</option>
                    <option>محل</option>
                    <option>أرض</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">ملاحظات</label>
                <textarea rows={3} className="admin-input resize-none" placeholder="ملاحظات عن احتياجات العميل..."></textarea>
              </div>
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3">
              <button onClick={() => setShowAddModal(false)} className="admin-btn border border-slate-200 text-slate-600">إلغاء</button>
              <button onClick={() => { toast.success('تم إضافة العميل'); setShowAddModal(false); }} className="admin-btn-primary">حفظ</button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
