// apps/admin/components/Sidebar.js
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import {
  LayoutDashboard, Building, Users, Briefcase, Wrench,
  BarChart3, Settings, LogOut, ChevronLeft, Menu, X,
  Phone, Mail, Shield, FileText, Factory, Hammer, Package
} from 'lucide-react';

export default function Sidebar({ isOpen, setIsOpen, userRole = 'MANAGER' }) {
  const router = useRouter();
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Menu items for all users
  const publicMenuItems = [
    { href: '/dashboard', label: 'الرئيسية', icon: LayoutDashboard },
    { href: '/properties', label: 'العقارات', icon: Building },
    { href: '/customers', label: 'العملاء', icon: Users },
    { href: '/leads', label: 'العملاء المحتملين', icon: Phone },
    { href: '/jobs', label: 'الوظائف', icon: Briefcase },
    { href: '/applicants', label: 'الباحثين عن عمل', icon: Users },
    { href: '/services', label: 'الخدمات', icon: Wrench },
    { href: '/reports', label: 'التقارير', icon: BarChart3 },
  ];

  // Menu items for Managers and Admins ONLY (Tenders & Factories)
  const managerMenuItems = [
    { 
      href: '/tenders', 
      label: 'المناقصات', 
      icon: FileText,
      badge: 'مدير فقط',
      badgeColor: 'bg-amber-500'
    },
    { 
      href: '/factories', 
      label: 'إدارة المصانع', 
      icon: Factory,
      badge: 'مدير فقط',
      badgeColor: 'bg-amber-500'
    },
  ];

  // Settings for all
  const settingsItem = { href: '/settings', label: 'الإعدادات', icon: Settings };

  // Combine based on role
  const isManager = userRole === 'MANAGER' || userRole === 'SUPER_ADMIN';
  const menuItems = isManager 
    ? [...publicMenuItems, ...managerMenuItems, settingsItem]
    : [...publicMenuItems, settingsItem];

  const isActive = (href) => router.pathname === href || router.pathname.startsWith(href + '/');

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setIsOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed top-0 right-0 h-full bg-slate-900 text-white z-50 transition-all duration-300 ${
        isOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
      } ${isCollapsed ? 'lg:w-20' : 'lg:w-72'} w-72`}>
        {/* Logo Area */}
        <div className="h-16 flex items-center justify-between px-6 border-b border-slate-800">
          <div className={`flex items-center gap-3 ${isCollapsed ? 'lg:hidden' : ''}`}>
            <div className="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center">
              <svg width="24" height="24" viewBox="0 0 200 200" fill="none">
                <rect x="60" y="70" width="55" height="90" rx="3" fill="white"/>
                <rect x="35" y="95" width="28" height="65" rx="2" fill="white" opacity="0.8"/>
                <rect x="112" y="95" width="28" height="65" rx="2" fill="white" opacity="0.8"/>
                <rect x="72" y="55" width="32" height="18" rx="2" fill="#fbbf24"/>
              </svg>
            </div>
            <div>
              <span className="font-bold text-lg">خدماتي</span>
              {isManager && (
                <span className="block text-[10px] text-amber-400">وضع المدير</span>
              )}
            </div>
          </div>
          <button onClick={() => setIsCollapsed(!isCollapsed)} className="hidden lg:block text-slate-400 hover:text-white">
            <ChevronLeft size={20} className={`transition-transform ${isCollapsed ? 'rotate-180' : ''}`} />
          </button>
          <button onClick={() => setIsOpen(false)} className="lg:hidden text-slate-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-1">
          {/* Public Menu Items */}
          {publicMenuItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                isActive(item.href)
                  ? 'bg-primary-600 text-white shadow-lg shadow-primary-600/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              onClick={() => setIsOpen(false)}
            >
              <item.icon size={20} />
              <span className={`${isCollapsed ? 'lg:hidden' : ''}`}>{item.label}</span>
            </Link>
          ))}

          {/* Manager-Only Section */}
          {isManager && (
            <>
              <div className={`pt-4 pb-2 ${isCollapsed ? 'lg:hidden' : ''}`}>
                <p className="px-4 text-xs font-bold text-amber-500 uppercase tracking-wider">
                  إدارة متقدمة
                </p>
                <p className="px-4 text-[10px] text-slate-500">خاص بالمدراء فقط</p>
              </div>
              {managerMenuItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                    isActive(item.href)
                      ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  <item.icon size={20} />
                  <span className={`${isCollapsed ? 'lg:hidden' : ''}`}>{item.label}</span>
                  {!isCollapsed && (
                    <span className="mr-auto text-[10px] bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded-full">
                      {item.badge}
                    </span>
                  )}
                </Link>
              ))}
            </>
          )}

          {/* Settings */}
          <div className="pt-4">
            <Link
              href={settingsItem.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                isActive(settingsItem.href)
                  ? 'bg-primary-600 text-white shadow-lg shadow-primary-600/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              onClick={() => setIsOpen(false)}
            >
              <Settings size={20} />
              <span className={`${isCollapsed ? 'lg:hidden' : ''}`}>{settingsItem.label}</span>
            </Link>
          </div>
        </nav>

        {/* Bottom */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-800">
          <div className={`px-4 pb-3 ${isCollapsed ? 'lg:hidden' : ''}`}>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Shield size={14} className="text-amber-500" />
              <span>{isManager ? 'صلاحيات مدير' : 'صلاحيات موظف'}</span>
            </div>
          </div>
          <button className="flex items-center gap-3 px-4 py-3 text-slate-400 hover:text-red-400 transition-colors w-full rounded-xl hover:bg-slate-800">
            <LogOut size={20} />
            <span className={`${isCollapsed ? 'lg:hidden' : ''}`}>تسجيل الخروج</span>
          </button>
        </div>
      </aside>
    </>
  );
}
