// apps/admin/layouts/AdminLayout.js
import { useState } from 'react';
import Sidebar from '../components/Sidebar';
import { Menu, Bell, Search, Shield } from 'lucide-react';

export default function AdminLayout({ children, title = 'لوحة التحكم', userRole = 'MANAGER' }) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div dir="rtl" className="min-h-screen bg-slate-50">
      <Sidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} userRole={userRole} />

      {/* Main Content */}
      <div className="lg:mr-72 transition-all duration-300">
        {/* Top Bar */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-2 hover:bg-slate-100 rounded-lg">
              <Menu size={24} className="text-slate-600" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-800">{title}</h1>
              {userRole === 'MANAGER' && (
                <span className="text-xs text-amber-600 flex items-center gap-1">
                  <Shield size={12} /> وضع المدير المتقدم
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2 bg-slate-100 rounded-lg px-4 py-2">
              <Search size={18} className="text-slate-400" />
              <input type="text" placeholder="بحث..." className="bg-transparent outline-none text-sm w-48" />
            </div>
            <button className="relative p-2 hover:bg-slate-100 rounded-lg">
              <Bell size={20} className="text-slate-600" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-primary-100 rounded-full flex items-center justify-center">
                <span className="text-primary-700 font-bold text-sm">م</span>
              </div>
              {userRole === 'MANAGER' && (
                <span className="hidden md:block text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded-full">
                  مدير
                </span>
              )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
