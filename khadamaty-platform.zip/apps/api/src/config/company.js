// apps/api/src/config/company.js
// ═══════════════════════════════════════════
// بيانات شركة خدماتي - قابلة للتعديل بالكامل
// ═══════════════════════════════════════════

const companyConfig = {
  // ═══ معلومات الشركة الأساسية ═══
  name: "خدماتي",
  nameEn: "Khadamaty",
  slogan: "حلول متكاملة لعالم الأعمال",
  sloganEn: "Integrated Solutions for Business",

  // ═══ بيانات التواصل ═══
  // يمكن إضافة أرقام وإيميلات جديدة هنا
  contact: {
    phones: [
      { number: "01091226300", label: "رئيسي", isPrimary: true },
      // أضف أرقام جديدة هنا:
      // { number: "01xxxxxxxxx", label: "فرع القاهرة", isPrimary: false },
    ],
    emails: [
      { address: "Nourmourad507@gmail.com", label: "رئيسي", isPrimary: true },
      // أضف إيميلات جديدة هنا:
      // { address: "sales@khadamaty.com", label: "المبيعات", isPrimary: false },
    ],
    whatsapp: "01091226300", // يمكن تغييره

    // مواقع التواصل الاجتماعي (اختياري)
    social: {
      facebook: "https://facebook.com/khadamaty",
      instagram: "https://instagram.com/khadamaty",
      linkedin: "https://linkedin.com/company/khadamaty",
      // يمكن إضافة المزيد
    }
  },

  // ═══ العنوان ═══
  address: {
    country: "مصر",
    city: "القاهرة",
    street: "",
    // يمكن إضافة فروع:
    branches: [
      // { city: "الإسكندرية", address: "...", phone: "..." }
    ]
  },

  // ═══ معلومات قانونية ═══
  legal: {
    commercialRegister: "", // السجل التجاري
    taxNumber: "", // الرقم الضريبي
  },

  // ═══ إعدادات المنصة ═══
  settings: {
    defaultLanguage: "ar", // ar | en
    supportedLanguages: ["ar", "en"],
    currency: "EGP", // ج.م
    currencySymbol: "ج.م",
    timezone: "Africa/Cairo",
    dateFormat: "DD/MM/YYYY",
  },

  // ═══ الأقسام الحالية ═══
  departments: [
    { id: "real-estate", name: "التسويق العقاري", icon: "🏠", isActive: true },
    { id: "recruitment", name: "التوظيف والعمالة", icon: "👷", isActive: true },
    { id: "services", name: "الخدمات العامة", icon: "🛠️", isActive: true },
    { id: "supplies", name: "التوريدات", icon: "📦", isActive: true },
    { id: "tenders", name: "المناقصات", icon: "📋", isActive: true },
    { id: "factories", name: "إدارة المصانع", icon: "🏭", isActive: true },
  ],

  // ═══ ألوان العلامة التجارية ═══
  branding: {
    primaryColor: "#0f766e", // teal-700
    secondaryColor: "#f59e0b", // amber-500
    accentColor: "#0ea5e9", // sky-500
    darkColor: "#0f172a", // slate-900
    lightColor: "#f8fafc", // slate-50
  },

  // ═══ إعدادات المصانع ═══
  factories: {
    categories: [
      "مواد بناء",
      "أثاث",
      "معدات",
      "صيانة",
      "كهرباء",
      "مواد غذائية",
      "تجهيزات",
      "ملابس",
    ],
    productionUnits: [
      "طن/شهر",
      "قطعة/شهر",
      "متر/شهر",
      "وحدة/شهر",
      "عملية/شهر",
    ]
  },

  // ═══ إعدادات المناقصات ═══
  tenders: {
    types: [
      { value: "GOVERNMENT", label: "حكومية" },
      { value: "PRIVATE", label: "خاصة" },
      { value: "INTERNATIONAL", label: "دولية" },
      { value: "LOCAL", label: "محلية" },
    ],
    categories: [
      "مواد بناء",
      "أثاث",
      "معدات",
      "صيانة",
      "خدمات",
      "توريدات",
      "إنشاءات",
    ],
    issuerTypes: [
      { value: "GOVERNMENT", label: "حكومي" },
      { value: "MILITARY", label: "عسكري" },
      { value: "PRIVATE_COMPANY", label: "شركة خاصة" },
      { value: "NGO", label: "جمعية أهلية" },
      { value: "INTERNATIONAL_ORG", label: "مؤسسة دولية" },
    ]
  }
};

module.exports = companyConfig;
