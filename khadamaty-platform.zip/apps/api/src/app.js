// apps/api/src/app.js
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const companyConfig = require('./config/company');

const app = express();

// Security middleware
app.use(helmet());
app.use(cors({
  origin: [process.env.WEB_URL, process.env.ADMIN_URL],
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', limiter);

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Logging
app.use(morgan('dev'));

// ═══ Public Routes ═══
app.use('/api/auth', require('./routes/auth'));
app.use('/api/company', require('./routes/company'));

// ═══ Protected Routes ═══
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/reports', require('./routes/reports'));

// Real Estate
app.use('/api/properties', require('./routes/properties'));
app.use('/api/customers', require('./routes/customers'));
app.use('/api/leads', require('./routes/leads'));

// Recruitment
app.use('/api/jobs', require('./routes/jobs'));
app.use('/api/applicants', require('./routes/applicants'));

// Services
app.use('/api/services', require('./routes/services'));

// ═══ Manager Only Routes (Tenders & Factories) ═══
app.use('/api/tenders', require('./routes/tenders'));
app.use('/api/factories', require('./routes/factories'));

// Company info endpoint (public)
app.get('/api/info', (req, res) => {
  res.json({
    success: true,
    data: {
      name: companyConfig.name,
      nameEn: companyConfig.nameEn,
      slogan: companyConfig.slogan,
      contact: companyConfig.contact,
      departments: companyConfig.departments.filter(d => d.isActive),
      branding: companyConfig.branding
    }
  });
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    success: false,
    error: err.message || 'Internal Server Error'
  });
});

module.exports = app;
