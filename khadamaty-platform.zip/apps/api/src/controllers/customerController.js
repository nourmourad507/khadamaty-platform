// apps/api/src/controllers/customerController.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getCustomers = async (req, res) => {
  try {
    const { status, source, search, assignedTo, page = 1, limit = 20 } = req.query;
    const where = {};

    if (status) where.status = status;
    if (source) where.source = source;
    if (assignedTo) where.assignedToId = assignedTo;
    if (search) {
      where.OR = [
        { fullName: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
        { email: { contains: search, mode: 'insensitive' } }
      ];
    }

    // Employee can only see their own customers
    if (req.user.role === 'EMPLOYEE') {
      where.assignedToId = req.user.id;
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [customers, total] = await Promise.all([
      prisma.customer.findMany({
        where,
        include: { assignedTo: { select: { id: true, fullName: true } }, leads: true },
        skip,
        take: parseInt(limit),
        orderBy: { createdAt: 'desc' }
      }),
      prisma.customer.count({ where })
    ]);

    res.json({
      success: true,
      data: customers,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, pages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getCustomer = async (req, res) => {
  try {
    const customer = await prisma.customer.findUnique({
      where: { id: req.params.id },
      include: {
        assignedTo: { select: { id: true, fullName: true } },
        leads: { include: { property: true } },
        callLogs: true
      }
    });
    if (!customer) return res.status(404).json({ success: false, error: 'Customer not found' });
    res.json({ success: true, data: customer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.createCustomer = async (req, res) => {
  try {
    const data = req.body;
    if (!data.assignedToId) data.assignedToId = req.user.id;

    const customer = await prisma.customer.create({ data });
    res.status(201).json({ success: true, data: customer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.updateCustomer = async (req, res) => {
  try {
    const customer = await prisma.customer.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json({ success: true, data: customer });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.deleteCustomer = async (req, res) => {
  try {
    await prisma.customer.delete({ where: { id: req.params.id } });
    res.json({ success: true, message: 'Customer deleted' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Add call log
exports.addCallLog = async (req, res) => {
  try {
    const { customerId } = req.params;
    const { callType, duration, notes } = req.body;

    const callLog = await prisma.callLog.create({
      data: { customerId, callType, duration: parseInt(duration), notes }
    });

    res.status(201).json({ success: true, data: callLog });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
