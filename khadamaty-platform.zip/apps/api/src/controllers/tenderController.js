// apps/api/src/controllers/tenderController.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Get all tenders (Manager/Admin only)
exports.getTenders = async (req, res) => {
  try {
    const { status, type, search, page = 1, limit = 20 } = req.query;
    const where = {};

    if (status) where.status = status;
    if (type) where.type = type;
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { tenderNumber: { contains: search, mode: 'insensitive' } },
        { issuerName: { contains: search, mode: 'insensitive' } }
      ];
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [tenders, total] = await Promise.all([
      prisma.tender.findMany({
        where,
        include: {
          factory: { select: { id: true, name: true } },
          assignedTo: { select: { id: true, fullName: true } },
          _count: { select: { bids: true } }
        },
        skip,
        take: parseInt(limit),
        orderBy: { createdAt: 'desc' }
      }),
      prisma.tender.count({ where })
    ]);

    res.json({
      success: true,
      data: tenders,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, pages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getTender = async (req, res) => {
  try {
    const tender = await prisma.tender.findUnique({
      where: { id: req.params.id },
      include: {
        factory: true,
        assignedTo: { select: { id: true, fullName: true } },
        bids: { include: { createdBy: { select: { fullName: true } } } }
      }
    });
    if (!tender) return res.status(404).json({ success: false, error: 'Tender not found' });
    res.json({ success: true, data: tender });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.createTender = async (req, res) => {
  try {
    const data = req.body;
    const tenderNumber = `TND-${Date.now()}`;

    const tender = await prisma.tender.create({
      data: { ...data, tenderNumber },
      include: { factory: true }
    });

    res.status(201).json({ success: true, data: tender });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.updateTender = async (req, res) => {
  try {
    const tender = await prisma.tender.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json({ success: true, data: tender });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.deleteTender = async (req, res) => {
  try {
    await prisma.tender.delete({ where: { id: req.params.id } });
    res.json({ success: true, message: 'Tender deleted' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Tender Bids
exports.createBid = async (req, res) => {
  try {
    const { tenderId } = req.params;
    const data = req.body;
    const bidNumber = `BID-${Date.now()}`;

    const bid = await prisma.tenderBid.create({
      data: {
        ...data,
        tenderId,
        bidNumber,
        createdById: req.user.id
      },
      include: { tender: true }
    });

    res.status(201).json({ success: true, data: bid });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.updateBid = async (req, res) => {
  try {
    const bid = await prisma.tenderBid.update({
      where: { id: req.params.bidId },
      data: req.body
    });
    res.json({ success: true, data: bid });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Tender Statistics
exports.getTenderStats = async (req, res) => {
  try {
    const [total, byStatus, byType, wonBids, totalValue] = await Promise.all([
      prisma.tender.count(),
      prisma.tender.groupBy({ by: ['status'], _count: { id: true } }),
      prisma.tender.groupBy({ by: ['type'], _count: { id: true } }),
      prisma.tenderBid.count({ where: { result: 'WON' } }),
      prisma.tender.aggregate({ _sum: { estimatedValue: true } })
    ]);

    res.json({
      success: true,
      data: {
        totalTenders: total,
        byStatus,
        byType,
        wonBids,
        totalEstimatedValue: totalValue._sum.estimatedValue || 0
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
