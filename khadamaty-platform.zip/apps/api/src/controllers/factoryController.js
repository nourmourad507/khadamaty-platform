// apps/api/src/controllers/factoryController.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getFactories = async (req, res) => {
  try {
    const { status, search, page = 1, limit = 20 } = req.query;
    const where = {};

    if (status) where.status = status;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { factoryCode: { contains: search, mode: 'insensitive' } }
      ];
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [factories, total] = await Promise.all([
      prisma.factory.findMany({
        where,
        include: {
          _count: {
            select: { products: true, tenders: true, productionOrders: true }
          }
        },
        skip,
        take: parseInt(limit),
        orderBy: { createdAt: 'desc' }
      }),
      prisma.factory.count({ where })
    ]);

    res.json({
      success: true,
      data: factories,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, pages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getFactory = async (req, res) => {
  try {
    const factory = await prisma.factory.findUnique({
      where: { id: req.params.id },
      include: {
        products: true,
        rawMaterials: true,
        productionOrders: true,
        tenders: true
      }
    });
    if (!factory) return res.status(404).json({ success: false, error: 'Factory not found' });
    res.json({ success: true, data: factory });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.createFactory = async (req, res) => {
  try {
    const data = req.body;
    const factoryCode = `FAC-${Date.now()}`;

    const factory = await prisma.factory.create({
      data: { ...data, factoryCode }
    });

    res.status(201).json({ success: true, data: factory });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.updateFactory = async (req, res) => {
  try {
    const factory = await prisma.factory.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json({ success: true, data: factory });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Factory Products
exports.getProducts = async (req, res) => {
  try {
    const { factoryId, search, page = 1, limit = 20 } = req.query;
    const where = { factoryId };

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { code: { contains: search, mode: 'insensitive' } }
      ];
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [products, total] = await Promise.all([
      prisma.factoryProduct.findMany({
        where,
        skip,
        take: parseInt(limit),
        orderBy: { createdAt: 'desc' }
      }),
      prisma.factoryProduct.count({ where })
    ]);

    res.json({
      success: true,
      data: products,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, pages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.createProduct = async (req, res) => {
  try {
    const product = await prisma.factoryProduct.create({ data: req.body });
    res.status(201).json({ success: true, data: product });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.updateProduct = async (req, res) => {
  try {
    const product = await prisma.factoryProduct.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json({ success: true, data: product });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Raw Materials
exports.getRawMaterials = async (req, res) => {
  try {
    const { factoryId } = req.query;
    const materials = await prisma.rawMaterial.findMany({
      where: { factoryId },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ success: true, data: materials });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.createRawMaterial = async (req, res) => {
  try {
    const material = await prisma.rawMaterial.create({ data: req.body });
    res.status(201).json({ success: true, data: material });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Production Orders
exports.getProductionOrders = async (req, res) => {
  try {
    const { factoryId, status } = req.query;
    const where = { factoryId };
    if (status) where.status = status;

    const orders = await prisma.productionOrder.findMany({
      where,
      include: { factory: { select: { name: true } } },
      orderBy: { createdAt: 'desc' }
    });

    res.json({ success: true, data: orders });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.createProductionOrder = async (req, res) => {
  try {
    const data = req.body;
    const orderNumber = `PRD-${Date.now()}`;

    const order = await prisma.productionOrder.create({
      data: { ...data, orderNumber }
    });

    res.status(201).json({ success: true, data: order });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Factory Statistics
exports.getFactoryStats = async (req, res) => {
  try {
    const { factoryId } = req.params;

    const [products, materials, orders, lowStock] = await Promise.all([
      prisma.factoryProduct.count({ where: { factoryId } }),
      prisma.rawMaterial.count({ where: { factoryId } }),
      prisma.productionOrder.count({ where: { factoryId } }),
      prisma.factoryProduct.count({ where: { factoryId, stockStatus: 'LOW_STOCK' } })
    ]);

    res.json({
      success: true,
      data: {
        totalProducts: products,
        totalMaterials: materials,
        totalOrders: orders,
        lowStockItems: lowStock
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
