// apps/api/src/controllers/propertyController.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Get all properties with filters
exports.getProperties = async (req, res) => {
  try {
    const { 
      status, type, city, region, minPrice, maxPrice, 
      minArea, maxArea, rooms, search, page = 1, limit = 20 
    } = req.query;

    const where = {};

    if (status) where.status = status;
    if (type) where.type = type;
    if (city) where.city = { contains: city, mode: 'insensitive' };
    if (region) where.region = { contains: region, mode: 'insensitive' };
    if (minPrice || maxPrice) {
      where.price = {};
      if (minPrice) where.price.gte = parseFloat(minPrice);
      if (maxPrice) where.price.lte = parseFloat(maxPrice);
    }
    if (minArea || maxArea) {
      where.area = {};
      if (minArea) where.area.gte = parseFloat(minArea);
      if (maxArea) where.area.lte = parseFloat(maxArea);
    }
    if (rooms) where.rooms = parseInt(rooms);
    if (search) {
      where.OR = [
        { projectName: { contains: search, mode: 'insensitive' } },
        { propertyCode: { contains: search, mode: 'insensitive' } },
        { ownerName: { contains: search, mode: 'insensitive' } }
      ];
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [properties, total] = await Promise.all([
      prisma.property.findMany({
        where,
        include: { assignedTo: { select: { id: true, fullName: true } } },
        skip,
        take: parseInt(limit),
        orderBy: { createdAt: 'desc' }
      }),
      prisma.property.count({ where })
    ]);

    res.json({
      success: true,
      data: properties,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, pages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Get single property
exports.getProperty = async (req, res) => {
  try {
    const property = await prisma.property.findUnique({
      where: { id: req.params.id },
      include: { assignedTo: { select: { id: true, fullName: true } }, leads: true }
    });
    if (!property) return res.status(404).json({ success: false, error: 'Property not found' });
    res.json({ success: true, data: property });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Create property
exports.createProperty = async (req, res) => {
  try {
    const data = req.body;
    const propertyCode = `PROP-${Date.now()}`;

    const property = await prisma.property.create({
      data: { ...data, propertyCode }
    });

    res.status(201).json({ success: true, data: property });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Update property
exports.updateProperty = async (req, res) => {
  try {
    const property = await prisma.property.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json({ success: true, data: property });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Delete property (soft delete by archiving)
exports.deleteProperty = async (req, res) => {
  try {
    await prisma.property.update({
      where: { id: req.params.id },
      data: { status: 'ARCHIVED' }
    });
    res.json({ success: true, message: 'Property archived successfully' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Smart matching - find properties for a customer
exports.getMatchingProperties = async (req, res) => {
  try {
    const { customerId } = req.params;
    const customer = await prisma.customer.findUnique({ where: { id: customerId } });

    if (!customer) return res.status(404).json({ success: false, error: 'Customer not found' });

    const properties = await prisma.property.findMany({
      where: { status: 'AVAILABLE' },
      include: { assignedTo: { select: { id: true, fullName: true } } }
    });

    // Calculate match score
    const scored = properties.map(prop => {
      let score = 0;

      // Budget match (40%)
      if (customer.budgetMin && customer.budgetMax) {
        if (prop.price >= customer.budgetMin && prop.price <= customer.budgetMax) score += 40;
        else if (prop.price <= customer.budgetMax * 1.1) score += 25;
      }

      // Region match (25%)
      if (customer.preferredRegion && prop.region === customer.preferredRegion) score += 25;
      else if (customer.preferredCity && prop.city === customer.preferredCity) score += 15;

      // Type match (15%)
      if (customer.needType && prop.type === customer.needType) score += 15;

      // Area match (10%)
      if (customer.minArea && customer.maxArea) {
        if (prop.area >= customer.minArea && prop.area <= customer.maxArea) score += 10;
      }

      // Payment method (10%)
      if (customer.paymentMethod && prop.paymentMethod === customer.paymentMethod) score += 10;

      return { ...prop, matchScore: score };
    });

    scored.sort((a, b) => b.matchScore - a.matchScore);

    res.json({ success: true, data: scored.filter(p => p.matchScore > 0) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
