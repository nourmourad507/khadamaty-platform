// apps/api/src/controllers/reportController.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getDashboardStats = async (req, res) => {
  try {
    const today = new Date();
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const startOfYear = new Date(today.getFullYear(), 0, 1);

    const [
      totalCustomers,
      newCustomersThisMonth,
      totalProperties,
      availableProperties,
      totalLeads,
      closedLeads,
      totalJobs,
      totalApplicants,
      customersBySource,
      propertiesByType,
      leadsByStatus
    ] = await Promise.all([
      prisma.customer.count(),
      prisma.customer.count({ where: { createdAt: { gte: startOfMonth } } }),
      prisma.property.count(),
      prisma.property.count({ where: { status: 'AVAILABLE' } }),
      prisma.lead.count(),
      prisma.lead.count({ where: { status: 'CLOSED_WON' } }),
      prisma.job.count(),
      prisma.applicant.count(),
      prisma.customer.groupBy({ by: ['source'], _count: { id: true } }),
      prisma.property.groupBy({ by: ['type'], _count: { id: true } }),
      prisma.lead.groupBy({ by: ['status'], _count: { id: true } })
    ]);

    res.json({
      success: true,
      data: {
        overview: {
          totalCustomers,
          newCustomersThisMonth,
          totalProperties,
          availableProperties,
          totalLeads,
          closedLeads,
          conversionRate: totalLeads > 0 ? ((closedLeads / totalLeads) * 100).toFixed(1) : 0,
          totalJobs,
          totalApplicants
        },
        charts: {
          customersBySource,
          propertiesByType,
          leadsByStatus
        }
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getEmployeePerformance = async (req, res) => {
  try {
    const employees = await prisma.user.findMany({
      where: { role: { in: ['EMPLOYEE', 'MANAGER'] } },
      include: {
        _count: {
          select: {
            assignedCustomers: true,
            assignedLeads: true
          }
        }
      }
    });

    const performance = await Promise.all(
      employees.map(async (emp) => {
        const closedLeads = await prisma.lead.count({
          where: { assignedToId: emp.id, status: 'CLOSED_WON' }
        });
        return {
          id: emp.id,
          name: emp.fullName,
          role: emp.role,
          customersCount: emp._count.assignedCustomers,
          leadsCount: emp._count.assignedLeads,
          closedDeals: closedLeads
        };
      })
    );

    res.json({ success: true, data: performance });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.exportData = async (req, res) => {
  try {
    const { type, format } = req.query;

    let data;
    switch (type) {
      case 'customers':
        data = await prisma.customer.findMany({
          include: { assignedTo: { select: { fullName: true } } }
        });
        break;
      case 'properties':
        data = await prisma.property.findMany({
          include: { assignedTo: { select: { fullName: true } } }
        });
        break;
      case 'leads':
        data = await prisma.lead.findMany({
          include: { customer: true, property: true, assignedTo: { select: { fullName: true } } }
        });
        break;
      default:
        return res.status(400).json({ success: false, error: 'Invalid export type' });
    }

    if (format === 'json') {
      res.json({ success: true, data });
    } else {
      // CSV format
      res.json({ success: true, data, format: 'csv-ready' });
    }
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
