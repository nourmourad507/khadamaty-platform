// apps/api/src/controllers/leadController.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getLeads = async (req, res) => {
  try {
    const { status, assignedTo, page = 1, limit = 20 } = req.query;
    const where = {};

    if (status) where.status = status;
    if (assignedTo) where.assignedToId = assignedTo;

    if (req.user.role === 'EMPLOYEE') {
      where.assignedToId = req.user.id;
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [leads, total] = await Promise.all([
      prisma.lead.findMany({
        where,
        include: {
          customer: true,
          property: true,
          assignedTo: { select: { id: true, fullName: true } }
        },
        skip,
        take: parseInt(limit),
        orderBy: { createdAt: 'desc' }
      }),
      prisma.lead.count({ where })
    ]);

    res.json({
      success: true,
      data: leads,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, pages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.createLead = async (req, res) => {
  try {
    const data = req.body;
    if (!data.assignedToId) data.assignedToId = req.user.id;

    const lead = await prisma.lead.create({
      data,
      include: { customer: true, property: true }
    });

    res.status(201).json({ success: true, data: lead });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.updateLead = async (req, res) => {
  try {
    const lead = await prisma.lead.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json({ success: true, data: lead });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
