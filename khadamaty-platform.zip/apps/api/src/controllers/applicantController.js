// apps/api/src/controllers/applicantController.js
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.getApplicants = async (req, res) => {
  try {
    const { status, profession, governorate, search, page = 1, limit = 20 } = req.query;
    const where = {};

    if (status) where.status = status;
    if (profession) where.profession = { contains: profession, mode: 'insensitive' };
    if (governorate) where.governorate = { contains: governorate, mode: 'insensitive' };
    if (search) {
      where.OR = [
        { fullName: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
        { profession: { contains: search, mode: 'insensitive' } }
      ];
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [applicants, total] = await Promise.all([
      prisma.applicant.findMany({
        where,
        include: { applications: { include: { job: true } } },
        skip,
        take: parseInt(limit),
        orderBy: { createdAt: 'desc' }
      }),
      prisma.applicant.count({ where })
    ]);

    res.json({
      success: true,
      data: applicants,
      pagination: { page: parseInt(page), limit: parseInt(limit), total, pages: Math.ceil(total / parseInt(limit)) }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.getApplicant = async (req, res) => {
  try {
    const applicant = await prisma.applicant.findUnique({
      where: { id: req.params.id },
      include: { applications: { include: { job: true } } }
    });
    if (!applicant) return res.status(404).json({ success: false, error: 'Applicant not found' });
    res.json({ success: true, data: applicant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.createApplicant = async (req, res) => {
  try {
    const applicant = await prisma.applicant.create({ data: req.body });
    res.status(201).json({ success: true, data: applicant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.updateApplicant = async (req, res) => {
  try {
    const applicant = await prisma.applicant.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json({ success: true, data: applicant });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Job Application
exports.applyForJob = async (req, res) => {
  try {
    const { jobId, applicantId } = req.body;

    const application = await prisma.jobApplication.create({
      data: { jobId, applicantId, status: 'PENDING' },
      include: { job: true, applicant: true }
    });

    res.status(201).json({ success: true, data: application });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.updateApplication = async (req, res) => {
  try {
    const application = await prisma.jobApplication.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json({ success: true, data: application });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
