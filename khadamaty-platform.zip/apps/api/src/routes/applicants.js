// apps/api/src/routes/applicants.js
const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const applicantController = require('../controllers/applicantController');

router.get('/', authenticate, applicantController.getApplicants);
router.get('/:id', authenticate, applicantController.getApplicant);
router.post('/', authenticate, applicantController.createApplicant);
router.put('/:id', authenticate, applicantController.updateApplicant);

module.exports = router;
