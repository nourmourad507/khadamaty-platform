// apps/api/src/routes/customers.js
const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const customerController = require('../controllers/customerController');

router.get('/', authenticate, customerController.getCustomers);
router.get('/:id', authenticate, customerController.getCustomer);
router.post('/', authenticate, customerController.createCustomer);
router.put('/:id', authenticate, customerController.updateCustomer);
router.delete('/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), customerController.deleteCustomer);
router.post('/:customerId/call-logs', authenticate, customerController.addCallLog);

module.exports = router;
