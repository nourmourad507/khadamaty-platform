// apps/api/src/routes/tenders.js
const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const tenderController = require('../controllers/tenderController');

// All tender routes require Manager or Admin
router.get('/', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), tenderController.getTenders);
router.get('/stats', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), tenderController.getTenderStats);
router.get('/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), tenderController.getTender);
router.post('/', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), tenderController.createTender);
router.put('/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), tenderController.updateTender);
router.delete('/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), tenderController.deleteTender);

// Bids
router.post('/:tenderId/bids', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), tenderController.createBid);
router.put('/:tenderId/bids/:bidId', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), tenderController.updateBid);

module.exports = router;
