// apps/api/src/routes/jobs.js
const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const jobController = require('../controllers/jobController');
const applicantController = require('../controllers/applicantController');

router.get('/', jobController.getJobs);
router.get('/:id', jobController.getJob);
router.post('/', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), jobController.createJob);
router.put('/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), jobController.updateJob);
router.delete('/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), jobController.deleteJob);

// Applications
router.post('/applications', authenticate, applicantController.applyForJob);
router.put('/applications/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), applicantController.updateApplication);

module.exports = router;
