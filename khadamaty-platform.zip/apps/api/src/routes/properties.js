// apps/api/src/routes/properties.js
const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const propertyController = require('../controllers/propertyController');

router.get('/', propertyController.getProperties);
router.get('/match/:customerId', authenticate, propertyController.getMatchingProperties);
router.get('/:id', propertyController.getProperty);
router.post('/', authenticate, authorize('SUPER_ADMIN', 'MANAGER', 'EMPLOYEE'), propertyController.createProperty);
router.put('/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER', 'EMPLOYEE'), propertyController.updateProperty);
router.delete('/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), propertyController.deleteProperty);

module.exports = router;
