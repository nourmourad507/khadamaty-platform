// apps/api/src/routes/leads.js
const express = require('express');
const router = express.Router();
const { authenticate } = require('../middleware/auth');
const leadController = require('../controllers/leadController');

router.get('/', authenticate, leadController.getLeads);
router.post('/', authenticate, leadController.createLead);
router.put('/:id', authenticate, leadController.updateLead);

module.exports = router;
