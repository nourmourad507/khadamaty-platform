// apps/api/src/routes/reports.js
const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const reportController = require('../controllers/reportController');

router.get('/dashboard', authenticate, reportController.getDashboardStats);
router.get('/employees', authenticate, authorize('SUPER_ADMIN', 'MANAGER', 'SUPERVISOR'), reportController.getEmployeePerformance);
router.get('/export', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), reportController.exportData);

module.exports = router;
