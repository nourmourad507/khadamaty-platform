// apps/api/src/routes/dashboard.js
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const router = express.Router();
const prisma = new PrismaClient();
const { authenticate, authorize } = require('../middleware/auth');

router.get('/stats', authenticate, async (req, res) => {
  try {
    const [
      totalCustomers,
      totalProperties,
      totalLeads,
      totalJobs,
      totalApplicants,
      availableProperties,
      newCustomers,
      closedLeads
    ] = await Promise.all([
      prisma.customer.count(),
      prisma.property.count(),
      prisma.lead.count(),
      prisma.job.count(),
      prisma.applicant.count(),
      prisma.property.count({ where: { status: 'AVAILABLE' } }),
      prisma.customer.count({ where: { status: 'NEW' } }),
      prisma.lead.count({ where: { status: 'CLOSED_WON' } })
    ]);

    res.json({
      success: true,
      data: {
        totalCustomers,
        totalProperties,
        totalLeads,
        totalJobs,
        totalApplicants,
        availableProperties,
        newCustomers,
        closedLeads,
        conversionRate: totalCustomers > 0 ? ((closedLeads / totalCustomers) * 100).toFixed(1) : 0
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
