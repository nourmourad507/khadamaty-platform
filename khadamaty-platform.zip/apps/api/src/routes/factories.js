// apps/api/src/routes/factories.js
const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const factoryController = require('../controllers/factoryController');

// All factory routes require Manager or Admin
router.get('/', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.getFactories);
router.get('/stats/:factoryId', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.getFactoryStats);
router.get('/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.getFactory);
router.post('/', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.createFactory);
router.put('/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.updateFactory);

// Products
router.get('/products', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.getProducts);
router.post('/products', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.createProduct);
router.put('/products/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.updateProduct);

// Raw Materials
router.get('/materials', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.getRawMaterials);
router.post('/materials', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.createRawMaterial);

// Production Orders
router.get('/orders', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.getProductionOrders);
router.post('/orders', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), factoryController.createProductionOrder);

module.exports = router;
