// apps/api/src/routes/services.js
const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const serviceController = require('../controllers/serviceController');

router.get('/', serviceController.getServices);
router.get('/requests', authenticate, serviceController.getServiceRequests);
router.post('/requests', serviceController.createServiceRequest);
router.put('/requests/:id', authenticate, authorize('SUPER_ADMIN', 'MANAGER'), serviceController.updateServiceRequest);

module.exports = router;
