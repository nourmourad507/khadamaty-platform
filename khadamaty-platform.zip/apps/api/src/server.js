// apps/api/src/server.js
require('dotenv').config();
const app = require('./app');
const companyConfig = require('./config/company');

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log('═══════════════════════════════════════');
  console.log(`  🏢  ${companyConfig.name} Platform`);
  console.log(`  🚀  Server running on port ${PORT}`);
  console.log(`  📧  ${companyConfig.contact.emails[0].address}`);
  console.log(`  📞  ${companyConfig.contact.phones[0].number}`);
  console.log('═══════════════════════════════════════');
});
