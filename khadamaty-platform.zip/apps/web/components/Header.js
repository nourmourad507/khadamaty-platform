// apps/web/components/Header.js
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Phone, Mail, Menu, X, Home, Building, Users, Wrench, ChevronDown } from 'lucide-react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '/', label: 'الرئيسية', icon: Home },
    { href: '#properties', label: 'العقارات', icon: Building },
    { href: '#jobs', label: 'التوظيف', icon: Users },
    { href: '#services', label: 'خدماتنا', icon: Wrench },
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
    }`}>
      {/* Top Bar */}
      <div className={`${isScrolled ? 'hidden' : 'block'} bg-primary-800 text-white py-2`}>
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center gap-6">
            <a href="tel:01091226300" className="flex items-center gap-2 hover:text-accent-300 transition-colors">
              <Phone size={16} />
              <span>01091226300</span>
            </a>
            <a href="mailto:Nourmourad507@gmail.com" className="flex items-center gap-2 hover:text-accent-300 transition-colors hidden md:flex">
              <Mail size={16} />
              <span>Nourmourad507@gmail.com</span>
            </a>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-accent-300 font-semibold">شركة خدماتي</span>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <nav className={`max-w-7xl mx-auto px-4 py-4 flex justify-between items-center ${
        isScrolled ? 'py-3' : ''
      }`}>
        {/* Logo */}
        <Link href="/" className="flex items-center gap-3">
          <div className="w-12 h-12 bg-primary-700 rounded-xl flex items-center justify-center shadow-lg">
            <svg width="32" height="32" viewBox="0 0 200 200" fill="none">
              <rect x="60" y="70" width="55" height="90" rx="3" fill="white" opacity="0.95"/>
              <rect x="35" y="95" width="28" height="65" rx="2" fill="white" opacity="0.85"/>
              <rect x="112" y="95" width="28" height="65" rx="2" fill="white" opacity="0.85"/>
              <rect x="72" y="55" width="32" height="18" rx="2" fill="#fbbf24"/>
            </svg>
          </div>
          <div className="hidden sm:block">
            <h1 className={`font-bold text-xl transition-colors ${isScrolled ? 'text-primary-800' : 'text-white'}`}>
              خدماتي
            </h1>
            <p className={`text-xs transition-colors ${isScrolled ? 'text-gray-500' : 'text-white/70'}`}>
              حلول متكاملة
            </p>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={`px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 ${
                isScrolled 
                  ? 'text-gray-700 hover:text-primary-700 hover:bg-primary-50' 
                  : 'text-white/90 hover:text-white hover:bg-white/10'
              }`}
            >
              <link.icon size={18} />
              <span>{link.label}</span>
            </a>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="hidden md:flex items-center gap-3">
          <a href="#contact" className="btn-primary text-sm py-2 px-6">
            تواصل معنا
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className={`md:hidden p-2 rounded-lg transition-colors ${
            isScrolled ? 'text-primary-800' : 'text-white'
          }`}
        >
          {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </nav>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-xl border-t">
          <div className="px-4 py-4 space-y-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setIsMenuOpen(false)}
                className="flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-primary-50 hover:text-primary-700 transition-colors"
              >
                <link.icon size={20} />
                <span>{link.label}</span>
              </a>
            ))}
            <div className="pt-4 border-t">
              <a href="tel:01091226300" className="flex items-center gap-3 px-4 py-3 text-primary-700">
                <Phone size={20} />
                <span>01091226300</span>
              </a>
              <a href="mailto:Nourmourad507@gmail.com" className="flex items-center gap-3 px-4 py-3 text-primary-700">
                <Mail size={20} />
                <span>Nourmourad507@gmail.com</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
