// apps/web/components/Footer.js
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin, MessageCircle } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Company Info */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-primary-600 rounded-xl flex items-center justify-center">
                <svg width="28" height="28" viewBox="0 0 200 200" fill="none">
                  <rect x="60" y="70" width="55" height="90" rx="3" fill="white"/>
                  <rect x="35" y="95" width="28" height="65" rx="2" fill="white" opacity="0.8"/>
                  <rect x="112" y="95" width="28" height="65" rx="2" fill="white" opacity="0.8"/>
                  <rect x="72" y="55" width="32" height="18" rx="2" fill="#fbbf24"/>
                </svg>
              </div>
              <div>
                <h3 className="font-bold text-xl">خدماتي</h3>
                <p className="text-slate-400 text-sm">حلول متكاملة لعالم الأعمال</p>
              </div>
            </div>
            <p className="text-slate-400 leading-relaxed mb-6">
              نقدم حلولاً متكاملة في التسويق العقاري، التوظيف، والخدمات العامة بأعلى معايير الجودة والاحترافية.
            </p>
            <div className="flex gap-3">
              <a href="https://facebook.com/khadamaty" target="_blank" rel="noopener noreferrer" 
                 className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-primary-600 transition-colors">
                <Facebook size={18} />
              </a>
              <a href="https://instagram.com/khadamaty" target="_blank" rel="noopener noreferrer"
                 className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-primary-600 transition-colors">
                <Instagram size={18} />
              </a>
              <a href="https://linkedin.com/company/khadamaty" target="_blank" rel="noopener noreferrer"
                 className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-primary-600 transition-colors">
                <Linkedin size={18} />
              </a>
              <a href="https://wa.me/201091226300" target="_blank" rel="noopener noreferrer"
                 className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-green-600 transition-colors">
                <MessageCircle size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-lg mb-6 text-accent-400">روابط سريعة</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">الرئيسية</a></li>
              <li><a href="#properties" className="text-slate-400 hover:text-white transition-colors">العقارات</a></li>
              <li><a href="#jobs" className="text-slate-400 hover:text-white transition-colors">التوظيف</a></li>
              <li><a href="#services" className="text-slate-400 hover:text-white transition-colors">خدماتنا</a></li>
              <li><a href="#contact" className="text-slate-400 hover:text-white transition-colors">تواصل معنا</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold text-lg mb-6 text-accent-400">خدماتنا</h4>
            <ul className="space-y-3">
              <li><span className="text-slate-400">التسويق العقاري</span></li>
              <li><span className="text-slate-400">توفير العمالة</span></li>
              <li><span className="text-slate-400">الخدمات العامة</span></li>
              <li><span className="text-slate-400">التوريدات</span></li>
              <li><span className="text-slate-400">الاستشارات</span></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-lg mb-6 text-accent-400">تواصل معنا</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Phone size={20} className="text-primary-500 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-slate-300 font-semibold">رقم التواصل</p>
                  <a href="tel:01091226300" className="text-slate-400 hover:text-white transition-colors">01091226300</a>
                  {/* يمكن إضافة أرقام إضافية هنا */}
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail size={20} className="text-primary-500 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-slate-300 font-semibold">البريد الإلكتروني</p>
                  <a href="mailto:Nourmourad507@gmail.com" className="text-slate-400 hover:text-white transition-colors">Nourmourad507@gmail.com</a>
                  {/* يمكن إضافة إيميلات إضافية هنا */}
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin size={20} className="text-primary-500 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-slate-300 font-semibold">الموقع</p>
                  <p className="text-slate-400">القاهرة، مصر</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MessageCircle size={20} className="text-green-500 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-slate-300 font-semibold">واتساب</p>
                  <a href="https://wa.me/201091226300" target="_blank" rel="noopener noreferrer" 
                     className="text-slate-400 hover:text-white transition-colors">01091226300</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-500 text-sm">
            © {currentYear} شركة خدماتي. جميع الحقوق محفوظة.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-slate-500 hover:text-white transition-colors">سياسة الخصوصية</a>
            <a href="#" className="text-slate-500 hover:text-white transition-colors">الشروط والأحكام</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
