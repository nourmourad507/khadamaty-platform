// apps/web/pages/index.js
import { useState, useEffect } from 'react';
import Head from 'next/head';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { 
  Building, Users, Wrench, Package, Phone, Mail, MapPin, 
  ChevronLeft, Star, TrendingUp, Shield, Clock, CheckCircle,
  ArrowRight, Home, Briefcase, Handshake, MessageCircle
} from 'lucide-react';

export default function HomePage() {
  const [isVisible, setIsVisible] = useState({});

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          setIsVisible((prev) => ({ ...prev, [entry.target.id]: entry.isIntersecting }));
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('.animate-on-scroll').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const services = [
    {
      icon: Building,
      title: 'التسويق العقاري',
      description: 'نوفر تشكيلة واسعة من العقارات السكنية والتجارية بأفضل الأسعار وفي أرقى المناطق',
      color: 'bg-primary-50 text-primary-700',
      features: ['شقق', 'فيلات', 'محلات', 'مكاتب', 'أراضي']
    },
    {
      icon: Users,
      title: 'التوظيف والعمالة',
      description: 'نوفر الكوادر المؤهلة والعمالة المدربة لجميع القطاعات بسرعة وكفاءة',
      color: 'bg-accent-50 text-accent-700',
      features: ['عمالة فنية', 'إدارية', 'سائقين', 'أمن', 'خدمات منزلية']
    },
    {
      icon: Wrench,
      title: 'الخدمات العامة',
      description: 'خدمات متكاملة للشركات والأفراف تشمل الصيانة والتنظيف والتوريدات',
      color: 'bg-sky-50 text-sky-700',
      features: ['صيانة', 'تنظيف', 'أمن', 'استشارات', 'توريدات']
    },
    {
      icon: Package,
      title: 'التوريدات',
      description: 'نوفر جميع مستلزمات الشركات والمصانع بجودة عالية وأسعار تنافسية',
      color: 'bg-emerald-50 text-emerald-700',
      features: ['مواد خام', 'معدات', 'أثاث مكتبي', 'أدوات', 'مستلزمات']
    }
  ];

  const stats = [
    { number: '500+', label: 'عميل سعيد', icon: Users },
    { number: '300+', label: 'عقار متاح', icon: Building },
    { number: '1000+', label: 'موظف مؤهل', icon: Briefcase },
    { number: '50+', label: 'شركة شريكة', icon: Handshake },
  ];

  const features = [
    { icon: Shield, title: 'ثقة وأمان', description: 'نلتزم بأعلى معايير الشفافية والمصداقية في جميع تعاملاتنا' },
    { icon: Clock, title: 'سرعة التنفيذ', description: 'نحرص على إنجاز المهام في أسرع وقت دون المساس بالجودة' },
    { icon: Star, title: 'جودة عالية', description: 'نختار بعناية كل ما نقدمه لضمان رضا عملائنا الكامل' },
    { icon: TrendingUp, title: 'أسعار تنافسية', description: 'نقدم أفضل الأسعار في السوق مع ضمان الجودة' },
  ];

  const testimonials = [
    { name: 'أحمد محمد', role: 'مستثمر عقاري', text: 'تعاملت مع شركة خدماتي في شراء عقارين، والصراحة التعامل كان أكثر من رائع والمصداقية عالية جداً.' },
    { name: 'سارة علي', role: 'مديرة شركة', text: 'وفروا لنا كوادر مؤهلة في وقت قياسي، والجودة كانت فوق التوقعات. أنصح بالتعامل معهم بشدة.' },
    { name: 'خالد محمود', role: 'صاحب مصنع', text: 'خدمات التوريد ممتازة والأسعار منافسة. التعامل معهم وفر لنا وقت وجهد كبير.' },
  ];

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">
      <Head>
        <title>خدماتي | حلول متكاملة لعالم الأعمال</title>
        <meta name="description" content="شركة خدماتي - التسويق العقاري، التوظيف، الخدمات العامة والتوريدات" />
      </Head>

      <Header />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary-900 via-primary-800 to-slate-900">
          <div className="absolute inset-0 opacity-20" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
          }} />
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-accent-500/20 rounded-full blur-xl animate-pulse" />
        <div className="absolute bottom-40 right-20 w-32 h-32 bg-primary-500/20 rounded-full blur-xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-white/10 rounded-full blur-lg animate-pulse" style={{ animationDelay: '2s' }} />

        <div className="relative z-10 max-w-7xl mx-auto px-4 py-32 text-center">
          <div className="animate-fade-in-up">
            {/* Logo */}
            <div className="w-24 h-24 mx-auto mb-8 bg-white/10 backdrop-blur-sm rounded-3xl flex items-center justify-center border border-white/20 shadow-2xl">
              <svg width="60" height="60" viewBox="0 0 200 200" fill="none">
                <rect x="60" y="70" width="55" height="90" rx="3" fill="white"/>
                <rect x="35" y="95" width="28" height="65" rx="2" fill="white" opacity="0.8"/>
                <rect x="112" y="95" width="28" height="65" rx="2" fill="white" opacity="0.8"/>
                <rect x="72" y="55" width="32" height="18" rx="2" fill="#fbbf24"/>
              </svg>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              شركة <span className="text-accent-400">خدماتي</span>
            </h1>
            <p className="text-xl md:text-2xl text-primary-100 mb-4 max-w-3xl mx-auto">
              حلول متكاملة لعالم الأعمال
            </p>
            <p className="text-lg text-white/70 mb-10 max-w-2xl mx-auto leading-relaxed">
              نقدم لك خدمات احترافية في التسويق العقاري، التوظيف، والخدمات العامة بأعلى معايير الجودة والمصداقية
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="#services" className="btn-accent text-lg py-4 px-10 flex items-center justify-center gap-2">
                <span>اكتشف خدماتنا</span>
                <ChevronLeft size={20} />
              </a>
              <a href="#contact" className="bg-white/10 hover:bg-white/20 text-white border border-white/30 font-bold py-4 px-10 rounded-xl transition-all duration-300 backdrop-blur-sm flex items-center justify-center gap-2">
                <Phone size={20} />
                <span>تواصل معنا</span>
              </a>
            </div>

            {/* Contact Quick Info */}
            <div className="mt-12 flex flex-wrap justify-center gap-6 text-white/80">
              <a href="tel:01091226300" className="flex items-center gap-2 hover:text-white transition-colors">
                <Phone size={18} className="text-accent-400" />
                <span>01091226300</span>
              </a>
              <span className="hidden sm:block text-white/30">|</span>
              <a href="mailto:Nourmourad507@gmail.com" className="flex items-center gap-2 hover:text-white transition-colors">
                <Mail size={18} className="text-accent-400" />
                <span>Nourmourad507@gmail.com</span>
              </a>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
            <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section id="stats" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="text-center p-6 rounded-2xl bg-gradient-to-br from-primary-50 to-primary-100/50 border border-primary-100">
                <stat.icon size={32} className="mx-auto mb-3 text-primary-600" />
                <div className="text-3xl font-bold text-primary-800 mb-1">{stat.number}</div>
                <div className="text-gray-600 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-primary-600 font-semibold text-sm uppercase tracking-wider">خدماتنا</span>
            <h2 className="section-title mt-2">حلول متكاملة لكل احتياجاتك</h2>
            <p className="section-subtitle">
              نقدم مجموعة متنوعة من الخدمات الاحترافية المصممة لتلبية جميع احتياجاتك بكفاءة وجودة عالية
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <div key={index} className="card p-8 group hover:-translate-y-2">
                <div className={`w-16 h-16 rounded-2xl ${service.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <service.icon size={32} />
                </div>
                <h3 className="font-bold text-xl mb-3 text-gray-900">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature, i) => (
                    <span key={i} className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs font-medium">
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-primary-600 font-semibold text-sm uppercase tracking-wider">لماذا نحن</span>
            <h2 className="section-title mt-2">نختلف لنميزك</h2>
            <p className="section-subtitle">
              نسعى دائماً لتقديم الأفضل من خلال التزامنا بمعايير الجودة والاحترافية في كل ما نقدمه
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-6">
                <div className="w-20 h-20 mx-auto mb-6 bg-primary-50 rounded-3xl flex items-center justify-center group-hover:bg-primary-100 transition-colors">
                  <feature.icon size={36} className="text-primary-600" />
                </div>
                <h3 className="font-bold text-xl mb-3 text-gray-900">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Properties Preview Section */}
      <section id="properties" className="py-20 bg-gradient-to-br from-primary-900 to-slate-900 text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-accent-400 font-semibold text-sm uppercase tracking-wider">العقارات</span>
            <h2 className="section-title mt-2 text-white">أفضل العقارات المتاحة</h2>
            <p className="text-gray-300 max-w-2xl mx-auto mb-8">
              تشكيلة متميزة من العقارات في أفضل المناطق بأسعار تنافسية
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: 'شقة فاخرة - التجمع الخامس', specs: '3 غرف | 2 حمام | 150م²', price: '2,500,000', status: 'متاح' },
              { title: 'فيلا - الشيخ زايد', specs: '5 غرف | 4 حمام | 400م²', price: '8,000,000', status: 'محجوز' },
              { title: 'محل تجاري - مدينة نصر', specs: '80م² | تشطيب سوبر لوكس', price: '3,200,000', status: 'متاح' },
            ].map((property, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-2xl overflow-hidden border border-white/10 hover:border-accent-500/50 transition-all duration-300 group">
                <div className="h-48 bg-gradient-to-br from-primary-800 to-primary-900 flex items-center justify-center relative">
                  <Building size={48} className="text-white/30" />
                  <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-bold ${
                    property.status === 'متاح' ? 'bg-green-500' : 'bg-amber-500'
                  }`}>
                    {property.status}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-bold text-lg mb-2">{property.title}</h3>
                  <p className="text-gray-400 text-sm mb-4">{property.specs}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-accent-400 font-bold text-xl">{property.price} ج.م</span>
                    <button className="text-white hover:text-accent-400 transition-colors flex items-center gap-1 text-sm">
                      التفاصيل <ArrowRight size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-10">
            <button className="btn-accent">
              عرض جميع العقارات
            </button>
          </div>
        </div>
      </section>

      {/* Jobs Preview Section */}
      <section id="jobs" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-primary-600 font-semibold text-sm uppercase tracking-wider">التوظيف</span>
            <h2 className="section-title mt-2">فرص عمل متاحة</h2>
            <p className="section-subtitle">
              نوفر فرص عمل متنوعة في مختلف المجالات للباحثين عن عمل
            </p>
          </div>

          <div className="max-w-4xl mx-auto space-y-4">
            {[
              { title: 'فني كهرباء', company: 'شركة المقاولات العربية', location: '6 أكتوبر', salary: '4,000 - 6,000', count: 5 },
              { title: 'سائق نقل ثقيل', company: 'مصر للنقل', location: 'الإسكندرية', salary: '5,000 - 7,000', count: 3 },
              { title: 'محاسب', company: 'شركة التجارة الدولية', location: 'القاهرة', salary: '6,000 - 8,000', count: 2 },
            ].map((job, index) => (
              <div key={index} className="card p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:border-primary-200">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Briefcase size={24} className="text-primary-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-gray-900">{job.title}</h3>
                    <p className="text-gray-600 text-sm">{job.company} - {job.location}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <MapPin size={14} /> {job.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users size={14} /> {job.count} مطلوب
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-primary-700 font-bold">{job.salary} ج.م</span>
                  <button className="btn-primary text-sm py-2 px-4">
                    التقديم
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-primary-600 font-semibold text-sm uppercase tracking-wider">آراء العملاء</span>
            <h2 className="section-title mt-2">ما يقوله عملاؤنا عنا</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="card p-8 relative">
                <div className="text-accent-400 text-6xl font-serif absolute top-4 right-6 opacity-20">"</div>
                <p className="text-gray-600 leading-relaxed mb-6 relative z-10">{testimonial.text}</p>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                    <span className="text-primary-700 font-bold text-lg">{testimonial.name[0]}</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                    <p className="text-gray-500 text-sm">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gradient-to-br from-primary-50 to-accent-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-primary-600 font-semibold text-sm uppercase tracking-wider">تواصل معنا</span>
            <h2 className="section-title mt-2">نحن هنا لمساعدتك</h2>
            <p className="section-subtitle">
              لا تتردد في التواصل معنا لأي استفسار أو طلب خدمة، فريقنا جاهز لخدمتك على مدار الساعة
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Contact Info */}
            <div className="space-y-6">
              <div className="card p-8">
                <h3 className="font-bold text-2xl mb-6 text-gray-900">بيانات التواصل</h3>

                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Phone size={24} className="text-primary-600" />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">رقم التواصل</h4>
                      <a href="tel:01091226300" className="text-primary-600 hover:text-primary-800 transition-colors text-lg">
                        01091226300
                      </a>
                      {/* يمكن إضافة أرقام إضافية هنا */}
                      <p className="text-gray-500 text-sm mt-1">متاح على مدار الساعة</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-accent-100 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Mail size={24} className="text-accent-600" />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">البريد الإلكتروني</h4>
                      <a href="mailto:Nourmourad507@gmail.com" className="text-primary-600 hover:text-primary-800 transition-colors text-lg">
                        Nourmourad507@gmail.com
                      </a>
                      {/* يمكن إضافة إيميلات إضافية هنا */}
                      <p className="text-gray-500 text-sm mt-1">نرد في أقرب وقت</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center flex-shrink-0">
                      <MessageCircle size={24} className="text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">واتساب</h4>
                      <a href="https://wa.me/201091226300" target="_blank" rel="noopener noreferrer" 
                         className="text-green-600 hover:text-green-800 transition-colors text-lg">
                        01091226300
                      </a>
                      <p className="text-gray-500 text-sm mt-1">تواصل مباشر عبر الواتساب</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-sky-100 rounded-xl flex items-center justify-center flex-shrink-0">
                      <MapPin size={24} className="text-sky-600" />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">العنوان</h4>
                      <p className="text-gray-600 text-lg">القاهرة، مصر</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="card p-8">
              <h3 className="font-bold text-2xl mb-6 text-gray-900">أرسل لنا رسالة</h3>
              <form className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">الاسم</label>
                    <input type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all" placeholder="اسمك الكامل" />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-medium mb-2">رقم الهاتف</label>
                    <input type="tel" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all" placeholder="01xxxxxxxxxx" />
                  </div>
                </div>
                <div>
                  <label className="block text-gray-700 font-medium mb-2">البريد الإلكتروني</label>
                  <input type="email" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all" placeholder="your@email.com" />
                </div>
                <div>
                  <label className="block text-gray-700 font-medium mb-2">نوع الخدمة</label>
                  <select className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all bg-white">
                    <option>اختر نوع الخدمة</option>
                    <option>التسويق العقاري</option>
                    <option>التوظيف والعمالة</option>
                    <option>الخدمات العامة</option>
                    <option>استفسار عام</option>
                  </select>
                </div>
                <div>
                  <label className="block text-gray-700 font-medium mb-2">الرسالة</label>
                  <textarea rows={4} className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all resize-none" placeholder="اكتب رسالتك هنا..."></textarea>
                </div>
                <button type="submit" className="btn-primary w-full py-4 text-lg">
                  إرسال الرسالة
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary-900 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            هل تبحث عن خدمة احترافية؟
          </h2>
          <p className="text-primary-100 text-lg mb-8 max-w-2xl mx-auto">
            فريق خدماتي جاهز لمساعدتك في تحقيق أهدافك. تواصل معنا الآن واحصل على استشارة مجانية
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="tel:01091226300" className="btn-accent text-lg py-4 px-10 flex items-center justify-center gap-2">
              <Phone size={20} />
              <span>اتصل الآن: 01091226300</span>
            </a>
            <a href="https://wa.me/201091226300" target="_blank" rel="noopener noreferrer" 
               className="bg-white/10 hover:bg-white/20 text-white border border-white/30 font-bold py-4 px-10 rounded-xl transition-all duration-300 flex items-center justify-center gap-2">
              <MessageCircle size={20} />
              <span>تواصل واتساب</span>
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
