// apps/web/pages/_app.js
import '../styles/globals.css';
import Head from 'next/head';

function MyApp({ Component, pageProps }) {
  return (
    <>
      <Head>
        <title>خدماتي | حلول متكاملة لعالم الأعمال</title>
        <meta name="description" content="منصة خدماتي - التسويق العقاري، التوظيف، الخدمات العامة والتوريدات" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/assets/logo/khadamaty-icon.svg" />
      </Head>
      <Component {...pageProps} />
    </>
  );
}

export default MyApp;
