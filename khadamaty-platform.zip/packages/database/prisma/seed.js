// packages/database/prisma/seed.js
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting seed...');

  // Create departments
  const departments = await prisma.department.createMany({
    data: [
      { name: 'التسويق العقاري', description: 'إدارة العقارات والعملاء', icon: 'Building' },
      { name: 'التوظيف', description: 'الوظائف والعمالة', icon: 'Users' },
      { name: 'الخدمات العامة', description: 'الخدمات والتوريدات', icon: 'Wrench' },
      { name: 'المناقصات', description: 'المناقصات والمصانع', icon: 'FileText' },
    ],
    skipDuplicates: true
  });

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 12);
  const admin = await prisma.user.create({
    data: {
      email: 'admin@khadamaty.com',
      passwordHash: adminPassword,
      fullName: 'المدير العام',
      phone: '01091226300',
      role: 'SUPER_ADMIN',
      isActive: true
    }
  });

  // Create manager user
  const managerPassword = await bcrypt.hash('manager123', 12);
  const manager = await prisma.user.create({
    data: {
      email: 'manager@khadamaty.com',
      passwordHash: managerPassword,
      fullName: 'مدير القسم',
      phone: '01091226300',
      role: 'MANAGER',
      isActive: true
    }
  });

  // Create employee user
  const employeePassword = await bcrypt.hash('employee123', 12);
  const employee = await prisma.user.create({
    data: {
      email: 'employee@khadamaty.com',
      passwordHash: employeePassword,
      fullName: 'موظف',
      phone: '01091226300',
      role: 'EMPLOYEE',
      isActive: true
    }
  });

  // Create sample properties
  await prisma.property.createMany({
    data: [
      {
        propertyCode: 'PROP-001',
        projectName: 'كمبوند النخيل',
        region: 'التجمع الخامس',
        city: 'القاهرة',
        type: 'APARTMENT',
        area: 150,
        rooms: 3,
        bathrooms: 2,
        floor: 5,
        finishing: 'FULLY_FINISHED',
        price: 2500000,
        paymentMethod: 'كاش أو تقسيط',
        status: 'AVAILABLE',
        ownerName: 'شركة التعمير',
        commissionRate: 2.5
      },
      {
        propertyCode: 'PROP-002',
        projectName: 'فيلا الزهراء',
        region: 'الشيخ زايد',
        city: 'الجيزة',
        type: 'VILLA',
        area: 400,
        rooms: 5,
        bathrooms: 4,
        finishing: 'SUPER_LUX',
        price: 8000000,
        paymentMethod: 'كاش',
        status: 'AVAILABLE',
        ownerName: 'أحمد محمد',
        commissionRate: 2.0
      }
    ]
  });

  // Create sample customers
  await prisma.customer.createMany({
    data: [
      {
        fullName: 'محمد أحمد',
        phone: '01012345678',
        whatsapp: '01012345678',
        email: 'mohamed@email.com',
        source: 'FACEBOOK',
        needType: 'APARTMENT',
        budgetMin: 2000000,
        budgetMax: 3000000,
        preferredRegion: 'التجمع الخامس',
        paymentMethod: 'تقسيط',
        status: 'INTERESTED',
        assignedToId: employee.id
      },
      {
        fullName: 'سارة خالد',
        phone: '01098765432',
        whatsapp: '01098765432',
        email: 'sara@email.com',
        source: 'WHATSAPP',
        needType: 'VILLA',
        budgetMin: 5000000,
        budgetMax: 8000000,
        preferredRegion: 'الشيخ زايد',
        paymentMethod: 'كاش',
        status: 'NEW',
        assignedToId: employee.id
      }
    ]
  });

  // Create sample jobs
  await prisma.job.createMany({
    data: [
      {
        companyName: 'شركة المقاولات العربية',
        activityType: 'مقاولات',
        jobTitle: 'فني كهرباء',
        requiredCount: 5,
        salaryMin: 4000,
        salaryMax: 6000,
        workLocation: '6 أكتوبر',
        requirements: 'خبرة 3 سنوات على الأقل',
        status: 'OPEN'
      },
      {
        companyName: 'مصر للنقل',
        activityType: 'نقل',
        jobTitle: 'سائق نقل ثقيل',
        requiredCount: 3,
        salaryMin: 5000,
        salaryMax: 7000,
        workLocation: 'الإسكندرية',
        requirements: 'رخصة مهنية سارية',
        status: 'OPEN'
      }
    ]
  });

  // Create sample factories (Manager only)
  await prisma.factory.createMany({
    data: [
      {
        factoryCode: 'FAC-001',
        name: 'مصنع خدماتي للمواد الإنشائية',
        address: 'المنطقة الصناعية، القاهرة',
        city: 'القاهرة',
        governorate: 'القاهرة',
        phone: '01091226300',
        email: 'factory1@khadamaty.com',
        status: 'ACTIVE',
        productionCapacity: '5000 طن/شهر',
        workingHours: '8 ساعات/يوم',
        numberOfWorkers: 45
      },
      {
        factoryCode: 'FAC-002',
        name: 'مصنع خدماتي للأثاث المكتبي',
        address: 'المنطقة الصناعية، العاشر من رمضان',
        city: 'العاشر من رمضان',
        governorate: 'الشرقية',
        phone: '01091226300',
        email: 'factory2@khadamaty.com',
        status: 'ACTIVE',
        productionCapacity: '2000 قطعة/شهر',
        workingHours: '8 ساعات/يوم',
        numberOfWorkers: 30
      }
    ]
  });

  // Create sample tenders (Manager only)
  await prisma.tender.createMany({
    data: [
      {
        tenderNumber: 'TND-001',
        title: 'توريد مواد بناء - مشروع إسكان اجتماعي',
        type: 'GOVERNMENT',
        category: 'مواد بناء',
        issuerName: 'وزارة الإسكان',
        issuerType: 'GOVERNMENT',
        publishDate: new Date('2024-07-01'),
        closingDate: new Date('2024-08-15'),
        estimatedValue: 2500000,
        status: 'PUBLISHED',
        requirements: 'توريد 1000 طن أسمنت و 50 طن حديد',
        assignedToId: manager.id
      },
      {
        tenderNumber: 'TND-002',
        title: 'توريد أثاث مكتبي - شركة النصر',
        type: 'PRIVATE',
        category: 'أثاث',
        issuerName: 'شركة النصر للتجارة',
        issuerType: 'PRIVATE_COMPANY',
        publishDate: new Date('2024-07-05'),
        closingDate: new Date('2024-07-25'),
        estimatedValue: 800000,
        status: 'BID_SUBMITTED',
        assignedToId: manager.id
      }
    ]
  });

  console.log('✅ Seed completed successfully!');
  console.log('');
  console.log('🔑 Default Login Credentials:');
  console.log('  Admin:    admin@khadamaty.com / admin123');
  console.log('  Manager:  manager@khadamaty.com / manager123');
  console.log('  Employee: employee@khadamaty.com / employee123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
